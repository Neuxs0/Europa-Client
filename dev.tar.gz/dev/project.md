/home/michael/Documents/Europa_Client
├── build.gradle
├── CHANGELOG.md
├── COMMANDS.md
├── dev
│   ├── a.json
│   ├── project_dump.py
│   ├── project.json
│   └── project.md
├── full
│   ├── build
│   │   ├── classes
│   │   │   └── java
│   │   │       ├── main
│   │   │       └── test
│   │   └── resources
│   │       ├── main
│   │       └── test
│   ├── common
│   │   ├── build
│   │   │   ├── classes
│   │   │   │   └── java
│   │   │   │       ├── main
│   │   │   │       └── test
│   │   │   └── resources
│   │   │       ├── main
│   │   │       └── test
│   │   ├── build.gradle
│   │   └── src
│   │       └── main
│   │           ├── java
│   │           │   └── dev
│   │           │       └── neuxs
│   │           │           └── europa_client
│   │           │               ├── Client.java
│   │           │               ├── commands
│   │           │               │   ├── ClientCommand.java
│   │           │               │   ├── ClientCommandManager.java
│   │           │               │   ├── ClientCommandRegistry.java
│   │           │               │   ├── misc
│   │           │               │   │   ├── HelpCommand.java
│   │           │               │   │   ├── SayCommand.java
│   │           │               │   │   ├── TypeCommand.java
│   │           │               │   │   └── VersionCommand.java
│   │           │               │   ├── modules
│   │           │               │   │   ├── cheats
│   │           │               │   │   │   ├── NoClipCommand.java
│   │           │               │   │   │   ├── ReachCommand.java
│   │           │               │   │   │   └── SpeedCommand.java
│   │           │               │   │   └── utils
│   │           │               │   │       └── FullbrightCommand.java
│   │           │               │   └── utils
│   │           │               │       ├── DisconnectCommand.java
│   │           │               │       ├── PlayerListCommand.java
│   │           │               │       └── QuitGameCommand.java
│   │           │               ├── mixins
│   │           │               │   ├── BlockRaycastsMixin.java
│   │           │               │   ├── ChatMenuMixin.java
│   │           │               │   ├── EntityMixin.java
│   │           │               │   ├── GameSingletonsInterface.java
│   │           │               │   ├── NoClipPacketMixin.java
│   │           │               │   ├── UIMixin.java
│   │           │               │   └── YouDiedMenuMixin.java
│   │           │               ├── modules
│   │           │               │   ├── cheats
│   │           │               │   │   ├── NoClip.java
│   │           │               │   │   ├── Reach.java
│   │           │               │   │   └── Speed.java
│   │           │               │   ├── Module.java
│   │           │               │   ├── Modules.java
│   │           │               │   └── utils
│   │           │               │       └── Fullbright.java
│   │           │               ├── settings
│   │           │               │   └── Setting.java
│   │           │               └── utils
│   │           │                   ├── Chat.java
│   │           │                   ├── InputManager.java
│   │           │                   └── SyncModules.java
│   │           └── resources
│   │               ├── assets
│   │               │   └── europa_client
│   │               │       ├── icon.png
│   │               │       └── shaders
│   │               │           ├── chunk.frag.glsl
│   │               │           ├── chunk.vert.glsl
│   │               │           ├── chunk-water.frag.glsl
│   │               │           └── chunk-water.vert.glsl
│   │               └── europa_client.mixins.json
│   ├── puzzle
│   │   ├── build
│   │   │   ├── classes
│   │   │   │   └── java
│   │   │   │       ├── client
│   │   │   │       ├── main
│   │   │   │       └── test
│   │   │   └── resources
│   │   │       ├── client
│   │   │       ├── main
│   │   │       └── test
│   │   ├── build.gradle
│   │   └── src
│   │       ├── client
│   │       │   ├── java
│   │       │   │   └── dev
│   │       │   │       └── neuxs
│   │       │   │           └── europa_client
│   │       │   │               └── PuzzleClient.java
│   │       │   └── resources
│   │       │       └── europa_client.mixins.json
│   │       └── main
│   │           └── resources
│   │               ├── europa_client.manipulator
│   │               └── puzzle.mod.json
│   └── quilt
│       ├── build
│       │   ├── classes
│       │   │   └── java
│       │   │       ├── main
│       │   │       └── test
│       │   └── resources
│       │       ├── main
│       │       └── test
│       ├── build.gradle
│       └── src
│           └── main
│               ├── java
│               │   └── dev
│               │       └── neuxs
│               │           └── europa_client
│               │               └── QuiltClient.java
│               └── resources
│                   └── quilt.mod.json
├── gradle
│   └── wrapper
│       ├── gradle-wrapper.jar
│       └── gradle-wrapper.properties
├── gradle.properties
├── gradlew
├── gradlew.bat
├── icon_256x.png
├── icon.png
├── jitpack.yml
├── LICENSE
├── MODULES.md
├── nocheat
│   ├── build
│   │   ├── classes
│   │   │   └── java
│   │   │       ├── main
│   │   │       └── test
│   │   └── resources
│   │       ├── main
│   │       └── test
│   ├── common
│   │   ├── build
│   │   │   ├── classes
│   │   │   │   └── java
│   │   │   │       ├── main
│   │   │   │       └── test
│   │   │   └── resources
│   │   │       ├── main
│   │   │       └── test
│   │   ├── build.gradle
│   │   └── src
│   │       └── main
│   │           ├── java
│   │           │   └── dev
│   │           │       └── neuxs
│   │           │           └── europa_client
│   │           │               ├── Client.java
│   │           │               ├── commands
│   │           │               │   ├── ClientCommand.java
│   │           │               │   ├── ClientCommandManager.java
│   │           │               │   ├── ClientCommandRegistry.java
│   │           │               │   ├── misc
│   │           │               │   │   ├── HelpCommand.java
│   │           │               │   │   ├── SayCommand.java
│   │           │               │   │   ├── TypeCommand.java
│   │           │               │   │   └── VersionCommand.java
│   │           │               │   ├── modules
│   │           │               │   │   └── utils
│   │           │               │   │       └── FullbrightCommand.java
│   │           │               │   └── utils
│   │           │               │       ├── DisconnectCommand.java
│   │           │               │       ├── PlayerListCommand.java
│   │           │               │       └── QuitGameCommand.java
│   │           │               ├── mixins
│   │           │               │   ├── ChatMenuMixin.java
│   │           │               │   └── GameSingletonsInterface.java
│   │           │               ├── modules
│   │           │               │   ├── Module.java
│   │           │               │   ├── Modules.java
│   │           │               │   └── utils
│   │           │               │       └── Fullbright.java
│   │           │               └── utils
│   │           │                   └── Chat.java
│   │           └── resources
│   │               ├── assets
│   │               │   └── europa_client
│   │               │       ├── icon.png
│   │               │       └── shaders
│   │               │           ├── chunk.frag.glsl
│   │               │           ├── chunk.vert.glsl
│   │               │           ├── chunk-water.frag.glsl
│   │               │           └── chunk-water.vert.glsl
│   │               └── europa_client.mixins.json
│   ├── puzzle
│   │   ├── build
│   │   │   ├── classes
│   │   │   │   └── java
│   │   │   │       ├── client
│   │   │   │       ├── main
│   │   │   │       └── test
│   │   │   └── resources
│   │   │       ├── client
│   │   │       ├── main
│   │   │       └── test
│   │   ├── build.gradle
│   │   └── src
│   │       ├── client
│   │       │   ├── java
│   │       │   │   └── dev
│   │       │   │       └── neuxs
│   │       │   │           └── europa_client
│   │       │   │               └── PuzzleClient.java
│   │       │   └── resources
│   │       │       └── europa_client.mixins.json
│   │       └── main
│   │           └── resources
│   │               ├── europa_client.manipulator
│   │               └── puzzle.mod.json
│   └── quilt
│       ├── build
│       │   ├── classes
│       │   │   └── java
│       │   │       ├── main
│       │   │       └── test
│       │   └── resources
│       │       ├── main
│       │       └── test
│       ├── build.gradle
│       └── src
│           └── main
│               ├── java
│               │   └── dev
│               │       └── neuxs
│               │           └── europa_client
│               │               └── QuiltClient.java
│               └── resources
│                   └── quilt.mod.json
├── README.md
└── settings.gradle

153 directories, 99 files


### ./gradlew.bat:
```bat
@rem
@rem Copyright 2015 the original author or authors.
@rem
@rem Licensed under the Apache License, Version 2.0 (the "License");
@rem you may not use this file except in compliance with the License.
@rem You may obtain a copy of the License at
@rem
@rem      https://www.apache.org/licenses/LICENSE-2.0
@rem
@rem Unless required by applicable law or agreed to in writing, software
@rem distributed under the License is distributed on an "AS IS" BASIS,
@rem WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
@rem See the License for the specific language governing permissions and
@rem limitations under the License.
@rem

@if "%DEBUG%" == "" @echo off
@rem ##########################################################################
@rem
@rem  Gradle startup script for Windows
@rem
@rem ##########################################################################

@rem Set local scope for the variables with windows NT shell
if "%OS%"=="Windows_NT" setlocal

set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
set APP_BASE_NAME=%~n0
set APP_HOME=%DIRNAME%

@rem Resolve any "." and ".." in APP_HOME to make it shorter.
for %%i in ("%APP_HOME%") do set APP_HOME=%%~fi

@rem Add default JVM options here. You can also use JAVA_OPTS and GRADLE_OPTS to pass JVM options to this script.
set DEFAULT_JVM_OPTS="-Xmx64m" "-Xms64m"

@rem Find java.exe
if defined JAVA_HOME goto findJavaFromJavaHome

set JAVA_EXE=java.exe
%JAVA_EXE% -version >NUL 2>&1
if "%ERRORLEVEL%" == "0" goto execute

echo.
echo ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH.
echo.
echo Please set the JAVA_HOME variable in your environment to match the
echo location of your Java installation.

goto fail

:findJavaFromJavaHome
set JAVA_HOME=%JAVA_HOME:"=%
set JAVA_EXE=%JAVA_HOME%/bin/java.exe

if exist "%JAVA_EXE%" goto execute

echo.
echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME%
echo.
echo Please set the JAVA_HOME variable in your environment to match the
echo location of your Java installation.

goto fail

:execute
@rem Setup the command line

set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar


@rem Execute Gradle
"%JAVA_EXE%" %DEFAULT_JVM_OPTS% %JAVA_OPTS% %GRADLE_OPTS% "-Dorg.gradle.appname=%APP_BASE_NAME%" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*

:end
@rem End local scope for the variables with windows NT shell
if "%ERRORLEVEL%"=="0" goto mainEnd

:fail
rem Set variable GRADLE_EXIT_CONSOLE if you need the _script_ return code instead of
rem the _cmd.exe /c_ return code!
if  not "" == "%GRADLE_EXIT_CONSOLE%" exit 1
exit /b 1

:mainEnd
if "%OS%"=="Windows_NT" endlocal

:omega

```

### ./gradle.properties:
```properties
# Gradle options
org.gradle.jvmargs=-Xmx8192M
org.gradle.parallel=true
org.gradle.caching=true

# Shared Project Info
name=Europa Client
id=europa_client
version=2.0.0
group=dev.neuxs
description=A simple client by Neuxs

# Dependency Versions
cosmic_reach_version=0.4.4

# Cosmic Quilt
cosmic_quilt_version=2.3.2

# Puzzle Loader & Jigsaw (for the Puzzle Loader mod)
puzzle_loader_version=2.3.8
jigsaw_gradle_version=1.0.8
```

### ./jitpack.yml:
```yml
jdk:
  - openjdk17
```

### ./MODULES.md:
```md
# Modules
## Full Client
### Fullbright
- Description: Makes everything bright
- Settings: None
### No-Clip
- Description: Become a ghost, though one that can die again
- Settings:
    - speed \<float>
        - Default: 1.0
        - Minimum: 0.1
        - Maximum: 10.0
### Speed
- Description: Makes you go vroom
- Settings:
    - speed \<float>
        - Default: 1.5
        - Minimum: 0.1
        - Maximum: 10.0
### Reach
- Description: Slenderman?!?!?
- Settings:
    - distance \<float>
        - Default: 6.0
        - Minimum: 1.0
        - Maximum: 3.4028235e38

## No-Cheat Client
### Fullbright
- Description: Makes everything bright
- Settings: None
```

### ./CHANGELOG.md:
```md
# v1.2.1
Release time: 16:00 PDT, March 16, 2025
### Fixes
- Fixed fullbright for Cosmic Reach Alpha v0.4.4
### Misc
- Updated to Cosmic Reach Alpha v0.4.4
- Updated to require Puzzle Loader v2.3.8

# v1.2.0
Release time: 19:00 PDT, March 15, 2025
### Fixes
- Fixed keybinds activating in chat
- Fix the Client's name not correctly showing in ModMenu or Puzzle Loader's Mod Menu
### Commands
- Client type command (#type, #clientType)
- Version command (#version, #clientVersion)
### Cheats
- Added Speed cheat
- Added Reach cheat
### Misc
- Updated to Cosmic Reach Alpha v0.4.3
- A no-cheat version
- A minor rework on commands centered around a module (#\<module> set \<setting> \<value> instead of #set\<module>\<setting> \<value>)
- Added an icon for ModMenu and Puzzle Loader

# v1.1.0
Release time: 16:00 PDT, March 10, 2025
### Fixes
- Fixed removal of no-clip on respawn
### Commands
- Disconnect command (#disconnect, #dc, #quit, #exit)
- Quit Game command (#quitGame, #closeGame, #exitGame)
- Fullbright command (#fullbright, #fb)
- Player List command (#playerList, #pl)
### Misc
- Puzzle Loader support
- Better client chat logging

# v1.0.0
Release time: 05:30 PDT, March 9, 2025
### Commands
- Help command (#help, #h, #?)
- NoClip command (#noclip, #nc)
- Set NoClip Speed command (#setNoClipSpeed, #sncs, #setncspeed)
- Say command (#say)
### Cheats
- No-clip cheat

```

### ./.gitignore:
```unknown
.gradle/
run/

build/
bin/
dev/

!gradle/wrapper/gradle-wrapper.jar
!**/src/main/**/build/
!**/src/test/**/build/

### IntelliJ IDEA ###
.idea/
*.iws
*.iml
*.ipr
out/
!**/src/main/**/out/
!**/src/test/**/out/

### Eclipse ###
.apt_generated
.classpath
.factorypath
.project
.settings
.springBeans
.sts4-cache
!**/src/main/**/bin/
!**/src/test/**/bin/

### NetBeans ###
/nbproject/private/
/nbbuild/
/dist/
/nbdist/
/.nb-gradle/

### VS Code ###
.vscode/

### Mac OS ###
.DS_Store

```

### ./build.gradle:
```gradle
plugins {
    id "java-base"
}

allprojects {
    group = rootProject.property("group")
    version = rootProject.property("version")
}

subprojects {
    apply plugin: "java"
    repositories {
        maven {
            name "JitPack"
            url "https://jitpack.io"
        }
    }

    processResources {
        def resourceTargets = ["quilt.mod.json", "puzzle.mod.json"]

        def replaceProperties = [
                mod_version     : project.version,
                mod_group       : project.group,
                mod_description : project.description,
                mod_name        : project.name,
                mod_id          : rootProject.property("id")
        ]

        inputs.properties replaceProperties
        replaceProperties.put("project", project)
        filesMatching(resourceTargets) {
            expand replaceProperties
        }
    }
}

def mod_id = rootProject.property("id")
def mod_version = rootProject.property("version")

// Package distribution task
task packageDist {
    dependsOn project(":nocheat:puzzle").tasks.jar
    dependsOn project(":nocheat:quilt").tasks.jar
    dependsOn project(":full:puzzle").tasks.jar
    dependsOn project(":full:quilt").tasks.jar

    outputs.dir file("dist")

    doLast {
        def distDir = file("dist")
        distDir.mkdirs()

        def jarsToCopy = [
                [source: project(":nocheat:puzzle").tasks.jar.archiveFile, destination: distDir],
                [source: project(":nocheat:quilt").tasks.jar.archiveFile, destination: distDir],
                [source: project(":full:puzzle").tasks.jar.archiveFile, destination: distDir],
                [source: project(":full:quilt").tasks.jar.archiveFile, destination: distDir]
        ]
        jarsToCopy.each { jarInfo ->
            // Convert RegularFile to File using asFile
            def sourceJarFile = jarInfo.source.get().asFile
            def destinationDir = jarInfo.destination
            copy {
                from sourceJarFile
                into destinationDir
            }
            logger.lifecycle("Copied ${sourceJarFile.name} to ${destinationDir.path}")
        }
    }
}

// Cleanup task: Delete subproject build directories and extra folders.
task cleanBuildDirs(dependsOn: packageDist) {
    doLast {
        // Delete each subproject's build directory
        subprojects.each { subproject ->
            def buildDir = subproject.buildDir
            if (buildDir.exists()) {
                if (buildDir.deleteDir()) {
                    logger.lifecycle("Deleted build directory for ${subproject.name}: ${buildDir.path}")
                } else {
                    logger.lifecycle(
                            "Unable to delete build directory for ${subproject.name}: ${buildDir.path}"
                    )
                }
            }
        }

        // Extra folders to delete relative to the root project directory
        def extraFolders = [
                "full/build",
                "full/common/build",
                "full/common/bin",
                "full/puzzle/build",
                "full/puzzle/.gradle",
                "full/quilt/build",
                "full/quilt/bin",
                "nocheat/build",
                "nocheat/common/build",
                "nocheat/common/bin",
                "nocheat/puzzle/build",
                "nocheat/puzzle/.gradle",
                "nocheat/quilt/build",
                "nocheat/quilt/bin"
        ]

        extraFolders.each { folderPath ->
            def folder = file(folderPath)
            if (folder.exists()) {
                int attempts = 0
                boolean deletedSuccessfully = false
                while (attempts < 5 && !deletedSuccessfully) {
                    if (folder.deleteDir()) {
                        logger.lifecycle("Deleted folder: ${folder.path}")
                        deletedSuccessfully = true
                    } else {
                        attempts++
                        logger.lifecycle(
                                "Attempt ${attempts} to delete folder ${folder.path} failed. Retrying..."
                        )
                        Thread.sleep(1000)
                    }
                }
                if (!deletedSuccessfully) {
                    logger.lifecycle(
                            "WARNING: Could not delete folder: ${folder.path} after ${attempts} attempts."
                    )
                }
            } else {
                logger.lifecycle("Folder not found (skipped): ${folder.path}")
            }
        }
    }
}

tasks.named("build") {
    dependsOn packageDist
    finalizedBy cleanBuildDirs
}

```

### ./gradlew:
```unknown
#!/bin/sh

#
# Copyright © 2015-2021 the original authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

##############################################################################
#
#   Gradle start up script for POSIX generated by Gradle.
#
#   Important for running:
#
#   (1) You need a POSIX-compliant shell to run this script. If your /bin/sh is
#       noncompliant, but you have some other compliant shell such as ksh or
#       bash, then to run this script, type that shell name before the whole
#       command line, like:
#
#           ksh Gradle
#
#       Busybox and similar reduced shells will NOT work, because this script
#       requires all of these POSIX shell features:
#         * functions;
#         * expansions «$var», «${var}», «${var:-default}», «${var+SET}»,
#           «${var#prefix}», «${var%suffix}», and «$( cmd )»;
#         * compound commands having a testable exit status, especially «case»;
#         * various built-in commands including «command», «set», and «ulimit».
#
#   Important for patching:
#
#   (2) This script targets any POSIX shell, so it avoids extensions provided
#       by Bash, Ksh, etc; in particular arrays are avoided.
#
#       The "traditional" practice of packing multiple parameters into a
#       space-separated string is a well documented source of bugs and security
#       problems, so this is (mostly) avoided, by progressively accumulating
#       options in "$@", and eventually passing that to Java.
#
#       Where the inherited environment variables (DEFAULT_JVM_OPTS, JAVA_OPTS,
#       and GRADLE_OPTS) rely on word-splitting, this is performed explicitly;
#       see the in-line comments for details.
#
#       There are tweaks for specific operating systems such as AIX, CygWin,
#       Darwin, MinGW, and NonStop.
#
#   (3) This script is generated from the Groovy template
#       https://github.com/gradle/gradle/blob/master/subprojects/plugins/src/main/resources/org/gradle/api/internal/plugins/unixStartScript.txt
#       within the Gradle project.
#
#       You can find Gradle at https://github.com/gradle/gradle/.
#
##############################################################################

# Attempt to set APP_HOME

# Resolve links: $0 may be a link
app_path=$0

# Need this for daisy-chained symlinks.
while
    APP_HOME=${app_path%"${app_path##*/}"}  # leaves a trailing /; empty if no leading path
    [ -h "$app_path" ]
do
    ls=$( ls -ld "$app_path" )
    link=${ls#*' -> '}
    case $link in             #(
      /*)   app_path=$link ;; #(
      *)    app_path=$APP_HOME$link ;;
    esac
done

APP_HOME=$( cd "${APP_HOME:-./}" && pwd -P ) || exit

APP_NAME="Gradle"
APP_BASE_NAME=${0##*/}

# Add default JVM options here. You can also use JAVA_OPTS and GRADLE_OPTS to pass JVM options to this script.
DEFAULT_JVM_OPTS='"-Xmx64m" "-Xms64m"'

# Use the maximum available, or set MAX_FD != -1 to use that value.
MAX_FD=maximum

warn () {
    echo "$*"
} >&2

die () {
    echo
    echo "$*"
    echo
    exit 1
} >&2

# OS specific support (must be 'true' or 'false').
cygwin=false
msys=false
darwin=false
nonstop=false
case "$( uname )" in                #(
  CYGWIN* )         cygwin=true  ;; #(
  Darwin* )         darwin=true  ;; #(
  MSYS* | MINGW* )  msys=true    ;; #(
  NONSTOP* )        nonstop=true ;;
esac

CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar


# Determine the Java command to use to start the JVM.
if [ -n "$JAVA_HOME" ] ; then
    if [ -x "$JAVA_HOME/jre/sh/java" ] ; then
        # IBM's JDK on AIX uses strange locations for the executables
        JAVACMD=$JAVA_HOME/jre/sh/java
    else
        JAVACMD=$JAVA_HOME/bin/java
    fi
    if [ ! -x "$JAVACMD" ] ; then
        die "ERROR: JAVA_HOME is set to an invalid directory: $JAVA_HOME

Please set the JAVA_HOME variable in your environment to match the
location of your Java installation."
    fi
else
    JAVACMD=java
    which java >/dev/null 2>&1 || die "ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH.

Please set the JAVA_HOME variable in your environment to match the
location of your Java installation."
fi

# Increase the maximum file descriptors if we can.
if ! "$cygwin" && ! "$darwin" && ! "$nonstop" ; then
    case $MAX_FD in #(
      max*)
        MAX_FD=$( ulimit -H -n ) ||
            warn "Could not query maximum file descriptor limit"
    esac
    case $MAX_FD in  #(
      '' | soft) :;; #(
      *)
        ulimit -n "$MAX_FD" ||
            warn "Could not set maximum file descriptor limit to $MAX_FD"
    esac
fi

# Collect all arguments for the java command, stacking in reverse order:
#   * args from the command line
#   * the main class name
#   * -classpath
#   * -D...appname settings
#   * --module-path (only if needed)
#   * DEFAULT_JVM_OPTS, JAVA_OPTS, and GRADLE_OPTS environment variables.

# For Cygwin or MSYS, switch paths to Windows format before running java
if "$cygwin" || "$msys" ; then
    APP_HOME=$( cygpath --path --mixed "$APP_HOME" )
    CLASSPATH=$( cygpath --path --mixed "$CLASSPATH" )

    JAVACMD=$( cygpath --unix "$JAVACMD" )

    # Now convert the arguments - kludge to limit ourselves to /bin/sh
    for arg do
        if
            case $arg in                                #(
              -*)   false ;;                            # don't mess with options #(
              /?*)  t=${arg#/} t=/${t%%/*}              # looks like a POSIX filepath
                    [ -e "$t" ] ;;                      #(
              *)    false ;;
            esac
        then
            arg=$( cygpath --path --ignore --mixed "$arg" )
        fi
        # Roll the args list around exactly as many times as the number of
        # args, so each arg winds up back in the position where it started, but
        # possibly modified.
        #
        # NB: a `for` loop captures its iteration list before it begins, so
        # changing the positional parameters here affects neither the number of
        # iterations, nor the values presented in `arg`.
        shift                   # remove old arg
        set -- "$@" "$arg"      # push replacement arg
    done
fi

# Collect all arguments for the java command;
#   * $DEFAULT_JVM_OPTS, $JAVA_OPTS, and $GRADLE_OPTS can contain fragments of
#     shell script including quotes and variable substitutions, so put them in
#     double quotes to make sure that they get re-expanded; and
#   * put everything else in single quotes, so that it's not re-expanded.

set -- \
        "-Dorg.gradle.appname=$APP_BASE_NAME" \
        -classpath "$CLASSPATH" \
        org.gradle.wrapper.GradleWrapperMain \
        "$@"

# Use "xargs" to parse quoted args.
#
# With -n1 it outputs one arg per line, with the quotes and backslashes removed.
#
# In Bash we could simply go:
#
#   readarray ARGS < <( xargs -n1 <<<"$var" ) &&
#   set -- "${ARGS[@]}" "$@"
#
# but POSIX shell has neither arrays nor command substitution, so instead we
# post-process each arg (as a line of input to sed) to backslash-escape any
# character that might be a shell metacharacter, then use eval to reverse
# that process (while maintaining the separation between arguments), and wrap
# the whole thing up as a single "set" statement.
#
# This will of course break if any of these variables contains a newline or
# an unmatched quote.
#

eval "set -- $(
        printf '%s\n' "$DEFAULT_JVM_OPTS $JAVA_OPTS $GRADLE_OPTS" |
        xargs -n1 |
        sed ' s~[^-[:alnum:]+,./:=@_]~\\&~g; ' |
        tr '\n' ' '
    )" '"$@"'

exec "$JAVACMD" "$@"

```

### ./settings.gradle:
```gradle
buildscript() {
    repositories {
        maven {
            name "JitPack"
            url "https://jitpack.io"
        }
        maven {
            name = 'Fabric'
            url = 'https://maven.fabricmc.net/'
        }
        mavenCentral()
        gradlePluginPortal()
        mavenLocal()
    }
    dependencies {
        classpath "org.codeberg.CRModders:cosmic-loom:1.1.1"


        classpath "com.github.johnrengelman:shadow:8.1.1"
        classpath "com.github.PuzzleLoader:jigsaw:$jigsaw_gradle_version"
    }
}

include("full")
include("full:common")
include("full:quilt")
include("full:puzzle")

include("nocheat")
include("nocheat:common")
include("nocheat:quilt")
include("nocheat:puzzle")

rootProject.name = "EuropaClient"
```

### ./README.md:
```md
# Europa Client
A simple Cosmic Reach client by Neuxs.

## Features:
- Custom chat commands (See commands [here.](./COMMANDS.md))
- Modules (See modules [here.](./MODULES.md))
- A cheat and no-cheat version
- Keybinds to quickly enable modules

## Building
1. Run `./gradlew build`
2. Build files located in ./dist
```

### ./COMMANDS.md:
```md
# Commands
## Full Client
### Misc
- **Help**
    - Usage: #help
    - Aliases: #h, #?
    - Description: Returns all valid commands
- **Say**
    - Usage: #say \<message>
    - Aliases: None
    - Description: Sends the message to the server chat
- **Type**
    - Usage: #type
    - Aliases: #clientType
    - Description: Returns the type of Europa Client you are using (Full or No-Cheat)
- **Version**
    - Usage: #version
    - Aliases: #clientVersion
    - Description: Returns what version of Europa Client you are using
### Utils
- **Disconnect**
    - Usage: #disconnect
    - Aliases: #dc, #quit, #exit
    - Description: Disconnects you from a server or singleplayer world
- **Quit Game**
    - Usage: #quitGame
    - Aliases: #gameQuit, #closeGame, #exitGame
    - Description: Quits the game
- **Player List**
    - Usage: #playerList
    - Aliases: #pl
    - Description: Returns with all online players on the server
### Modules
- **Fullbright**
    - Usage: #fullbright
    - Aliases: #fb
    - Description: Makes everything bright
    - Sub-commands: None
- **No-Clip**
    - Usage: #noclip
    - Aliases: #nc
    - Description: Become a ghost, though one that can die again
    - Sub-commands:
        - **set**
            - Usage: #noclip set \<setting> \<value>
            - Aliases: None
            - Description: Sets settings
            - Settings: <a href="./MODULES.md#no-clip">See here for settings</a>
- **Speed**
    - Usage: #speed
    - Aliases: #s
    - Description: Makes you go vroom
    - Sub-commands:
        - **set**
            - Usage: #speed set \<setting> \<value>
            - Aliases: None
            - Description: Sets settings
            - Settings: <a href="./MODULES.md#speed">See here for settings</a>
- **Reach**
    - Usage: #reach
    - Aliases: None
    - Description: Slenderman?!?!?
    - Sub-commands:
        - **set**
            - Usage: #reach set \<setting> \<value>
            - Aliases: None
            - Description: Sets settings
            - Settings: <a href="./MODULES.md#reach">See here for settings</a>

## No-Cheat Client
### Misc
- **Help**
    - Usage: #help
    - Aliases: #h, #?
    - Description: Returns all valid commands
- **Say**
    - Usage: #say \<message>
    - Aliases: None
    - Description: Sends the message to the server chat
- **Type**
    - Usage: #type
    - Aliases: #clientType
    - Description: Returns the type of Europa Client you are using (Full or No-Cheat)
- **Version**
    - Usage: #version
    - Aliases: #clientVersion
    - Description: Returns what version of Europa Client you are using
### Utils
- **Disconnect**
    - Usage: #disconnect
    - Aliases: #dc, #quit, #exit
    - Description: Disconnects you from a server or singleplayer world
- **Quit Game**
    - Usage: #quitGame
    - Aliases: #gameQuit, #closeGame, #exitGame
    - Description: Quits the game
- **Player List**
    - Usage: #playerList
    - Aliases: #pl
    - Description: Returns with all online players on the server
### Modules
- **Fullbright**
    - Usage: #fullbright
    - Aliases: #fb
    - Description: Makes everything bright
- **Freecam**
    - Usage: #freecam
    - Aliases: #fc
    - Description: Detatch the camera from the player (Cannot clip through blocks)
    - Sub-commands:
        - **set**
            - Usage: #freecam set \<setting> \<value>
            - Aliases: None
            - Description: Sets settings for freecam
            - Settings: <a href="./MODULES.md#freecam-1">See here for settings</a>
```

### ./nocheat/common/build.gradle:
```gradle
plugins {
    id 'java'
    id "cosmicloom"
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

loom {

}

repositories {
    mavenCentral()
}

dependencies {
    cosmicReach(loom.cosmicReachClient("alpha", cosmic_reach_version))
    cosmicReachServer(loom.cosmicReachServer("alpha", cosmic_reach_version))
    modImplementation(loom.cosmicQuilt(cosmic_quilt_version))
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/Client.java:
```java
package dev.neuxs.europa_client;

import dev.neuxs.europa_client.commands.ClientCommandRegistry;
import dev.neuxs.europa_client.modules.Modules;
import finalforeach.cosmicreach.chat.Chat;
import finalforeach.cosmicreach.chat.IChat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Client {
    public static final String MOD_ID = "europa_client";
    public static final String MOD_NAME = "Europa Client No-Cheat";
    public static Logger LOGGER = LoggerFactory.getLogger("EuropaClient");
    public static String VERSION = "1.2.0";
    public static IChat clientChat = Chat.MAIN_CLIENT_CHAT;

    public static void init() {
        LOGGER.info("Europa Client Initializing...");

        Modules.initModules();
        ClientCommandRegistry.registerClientCommands();

        LOGGER.info("Europa Client Initialized!");
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/ClientCommandRegistry.java:
```java
package dev.neuxs.europa_client.commands;

import dev.neuxs.europa_client.commands.misc.HelpCommand;
import dev.neuxs.europa_client.commands.misc.SayCommand;
import dev.neuxs.europa_client.commands.misc.TypeCommand;
import dev.neuxs.europa_client.commands.misc.VersionCommand;
import dev.neuxs.europa_client.commands.utils.DisconnectCommand;
import dev.neuxs.europa_client.commands.modules.utils.FullbrightCommand;
import dev.neuxs.europa_client.commands.utils.PlayerListCommand;
import dev.neuxs.europa_client.commands.utils.QuitGameCommand;

public class ClientCommandRegistry {
    public static void registerClientCommands() {
        // Misc
        ClientCommandManager.registerCommand("say", SayCommand::new);
        ClientCommandManager.registerCommand("help", HelpCommand::new, "?", "h");
        ClientCommandManager.registerCommand("type", TypeCommand::new, "clientType");
        ClientCommandManager.registerCommand("version", VersionCommand::new, "clientVersion");

        // Utils
        ClientCommandManager.registerCommand("disconnect", DisconnectCommand::new, "dc", "quit", "exit");
        ClientCommandManager.registerCommand("quitGame", QuitGameCommand::new, "gameQuit", "closeGame", "exitGame");
        ClientCommandManager.registerCommand("playerList", PlayerListCommand::new, "pl");

        // Modules - Utils
        ClientCommandManager.registerCommand("fullbright", FullbrightCommand::new, "fb");
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/ClientCommand.java:
```java
package dev.neuxs.europa_client.commands;

import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.accounts.Account;

public abstract class ClientCommand {
    protected Account account;
    protected String[] args;

    public ClientCommand() {}

    public void setup(Account account, String[] args) {
        this.account = account;
        this.args = args;
    }

    public abstract void run();

    public abstract String getDescription();
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/ClientCommandManager.java:
```java
package dev.neuxs.europa_client.commands;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import dev.neuxs.europa_client.Client;
import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.accounts.Account;

public class ClientCommandManager {

    private static final Map<String, Supplier<ClientCommand>> COMMANDS =
            new HashMap<>();
    private static final Map<String, Supplier<ClientCommand>> ALIASES =
            new HashMap<>();

    public static void registerCommand(
            String name,
            Supplier<ClientCommand> supplier,
            String... aliases
    ) {
        name = name.toLowerCase();
        if (COMMANDS.containsKey(name)) {
            System.err.println("ClientCommand `" + name + "` already registered!");
        }
        COMMANDS.put(name, supplier);

        for (String alias : aliases) {
            alias = alias.toLowerCase();
            if (COMMANDS.containsKey(alias) || ALIASES.containsKey(alias)) {
                System.err.println("Alias `" + alias + "` already registered!");
            } else {
                ALIASES.put(alias, supplier);
            }
        }
    }

    public static void triggerCommand(
            Account account,
            String messageText
    ) {
        String withoutPrefix = messageText.substring(1);

        String[] args;
        String commandStr;
        if (withoutPrefix.toLowerCase().startsWith("say ")) {
            commandStr = "say";
            String rest = withoutPrefix.substring(4);
            args = new String[]{commandStr, rest};
        } else {
            String[] parts = withoutPrefix.split(" ");
            commandStr = parts[0].toLowerCase();
            args = withoutPrefix.split(" ");
        }

        Supplier<ClientCommand> supplier = COMMANDS.get(commandStr);
        if (supplier == null) {
            supplier = ALIASES.get(commandStr);
        }
        if (supplier == null) {
            Client.clientChat.addMessage(null, "Unknown command: " + commandStr);
            return;
        }
        ClientCommand command = supplier.get();
        command.setup(account, args);
        try {
            command.run();
        } catch (Exception e) {
            Client.clientChat.addMessage(null, "Error running command: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void printHelp(IChat chat) {
        StringBuilder sb = new StringBuilder("Available commands:\n");
        for (String cmd : COMMANDS.keySet()) {
            Supplier<ClientCommand> supplier = COMMANDS.get(cmd);
            ClientCommand command = supplier.get();
            sb.append("#")
                    .append(cmd)
                    .append(" - ")
                    .append(command.getDescription())
                    .append("\n");
        }
        Client.clientChat.addMessage(null, sb.toString());
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/misc/HelpCommand.java:
```java
package dev.neuxs.europa_client.commands.misc;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.commands.ClientCommandManager;

public class HelpCommand extends ClientCommand {

    @Override
    public void run() {
        ClientCommandManager.printHelp(Client.clientChat);
    }

    @Override
    public String getDescription() {
        return "Displays help information for all Europa Client commands.";
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/misc/SayCommand.java:
```java
package dev.neuxs.europa_client.commands.misc;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;

public class SayCommand extends ClientCommand {

    @Override
    public void run() {
        if (args.length < 2 || args[1].trim().isEmpty()) {
            Client.clientChat.addMessage(null, "Usage: #say <message>");
            return;
        }

        String message = args[1].trim();
        Client.clientChat.addMessage(account, message);
    }

    @Override
    public String getDescription() {
        return "Sends a public chat message.";
    }
}
```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/misc/VersionCommand.java:
```java
package dev.neuxs.europa_client.commands.misc;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.utils.Chat;

public class VersionCommand extends ClientCommand {

    @Override
    public void run() {
        Client.clientChat.addMessage(null, Chat.getClientPrefix() + "You are running Europa Client v" + Client.VERSION);
    }

    @Override
    public String getDescription() {
        return "Tells you what version of Europa Client you are running.";
    }
}
```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/misc/TypeCommand.java:
```java
package dev.neuxs.europa_client.commands.misc;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.utils.Chat;

public class TypeCommand extends ClientCommand {

    @Override
    public void run() {
        Client.clientChat.addMessage(null, Chat.getClientPrefix() + "You are running the no-cheat Europa Client.");
    }

    @Override
    public String getDescription() {
        return "Tells you what type of Europa Client you are running.";
    }
}
```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/utils/PlayerListCommand.java:
```java
package dev.neuxs.europa_client.commands.utils;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.mixins.GameSingletonsInterface;
import dev.neuxs.europa_client.utils.Chat;
import finalforeach.cosmicreach.accounts.Account;
import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.entities.player.Player;
import java.util.WeakHashMap;

public class PlayerListCommand extends ClientCommand {

    @Override
    public void run() {
        WeakHashMap<Player, Account> playersToAccounts =
                GameSingletonsInterface.getPlayersToAccounts();

        if (playersToAccounts == null || playersToAccounts.isEmpty()) {
            Client.clientChat.addMessage(null,
                    Chat.getClientPrefix() + "No players online.");
            return;
        }

        StringBuilder playerList = new StringBuilder();
        int count = 0;
        for (Account account : playersToAccounts.values()) {
            if (count > 0) {
                playerList.append(", ");
            }
            playerList.append(account.getDisplayName());
            count++;
        }

        if (count == 1) {
            Client.clientChat.addMessage(null,
                    Chat.getClientPrefix() + "You are the only player online!");
        } else {
            Client.clientChat.addMessage(null,
                    Chat.getClientPrefix() + "Online players: " + playerList);
        }
    }

    @Override
    public String getDescription() {
        return "Shows all the online players on the server.";
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/utils/QuitGameCommand.java:
```java
package dev.neuxs.europa_client.commands.utils;

import com.badlogic.gdx.Gdx;
import dev.neuxs.europa_client.commands.ClientCommand;
import finalforeach.cosmicreach.GameSingletons;
import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.gamestates.*;
import finalforeach.cosmicreach.io.ChunkSaver;
import finalforeach.cosmicreach.networking.client.ClientNetworkManager;

public class QuitGameCommand extends ClientCommand {

    @Override
    public void run() {
        Gdx.app.postRunnable(() -> {
            if (Gdx.input.isCursorCatched()) Gdx.input.setCursorCatched(false);

            if (GameSingletons.isHost) {
                ChunkSaver.saveWorld(InGame.getWorld());
            } else {
                try {
                    ClientNetworkManager.CLIENT.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            GameState.switchToGameState(InGame.IN_GAME);
            GameState.switchToGameState(new MainMenu());
            System.exit(0);
        });
    }

    @Override
    public String getDescription() {
        return "Closes the game quickly and safely.";
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/utils/DisconnectCommand.java:
```java
package dev.neuxs.europa_client.commands.utils;

import com.badlogic.gdx.Gdx;
import dev.neuxs.europa_client.commands.ClientCommand;
import finalforeach.cosmicreach.GameSingletons;
import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.gamestates.*;
import finalforeach.cosmicreach.io.ChunkSaver;
import finalforeach.cosmicreach.networking.client.ClientNetworkManager;

public class DisconnectCommand extends ClientCommand {

    @Override
    public void run() {
        Gdx.app.postRunnable(() -> {
            if (Gdx.input.isCursorCatched()) Gdx.input.setCursorCatched(false);

            if (GameSingletons.isHost) {
                ChunkSaver.saveWorld(InGame.getWorld());
            } else {
                try {
                    ClientNetworkManager.CLIENT.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            GameState.switchToGameState(InGame.IN_GAME);
            GameState.switchToGameState(new MainMenu());
        });
    }

    @Override
    public String getDescription() {
        return "Disconnects yourself from the server.";
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/commands/modules/utils/FullbrightCommand.java:
```java
package dev.neuxs.europa_client.commands.modules.utils;

import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.modules.Modules;
import finalforeach.cosmicreach.gamestates.InGame;

public class FullbrightCommand extends ClientCommand {
    @Override
    public void run() {
        Modules.fullbright.toggle(InGame.getWorld(), true);
    }

    @Override
    public String getDescription() {
        return "Toggles fullbright.";
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/utils/Chat.java:
```java
package dev.neuxs.europa_client.utils;

public class Chat {
    public static String getClientPrefix() {
        return "[Europa Client] ";
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/modules/Module.java:
```java
package dev.neuxs.europa_client.modules;

public abstract class Module {
    public int keyBind;
    private boolean enabled;

    public Module(int keyBind, boolean defaultEnabled) {
        this.keyBind = keyBind;
        this.enabled = defaultEnabled;
    }

    public void toggle() {
        this.enabled = !this.enabled;
    }

    public void enable() {
        this.enabled = true;
    }

    public void disable() {
        this.enabled = false;
    }

    public boolean isEnabled() {
        return enabled;
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/modules/Modules.java:
```java
package dev.neuxs.europa_client.modules;

import com.badlogic.gdx.Input;
import dev.neuxs.europa_client.modules.utils.Fullbright;

public class Modules {
    // Utils
    public static Fullbright fullbright;

    public static void initModules() {
        // Utils
        int fullbrightKeybind = Input.Keys.UNKNOWN;
        fullbright = new Fullbright(fullbrightKeybind, false);
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/modules/utils/Fullbright.java:
```java
package dev.neuxs.europa_client.modules.utils;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.modules.Module;
import dev.neuxs.europa_client.utils.Chat;
import finalforeach.cosmicreach.GameSingletons;
import finalforeach.cosmicreach.rendering.shaders.ChunkShader;
import finalforeach.cosmicreach.rendering.shaders.GameShader;
import finalforeach.cosmicreach.util.Identifier;
import finalforeach.cosmicreach.world.Chunk;
import finalforeach.cosmicreach.world.Region;
import finalforeach.cosmicreach.world.World;
import finalforeach.cosmicreach.world.Zone;

public class Fullbright extends Module {

    public Fullbright(int keybind, boolean defaultEnabled) {
        super(keybind, defaultEnabled);
    }

    public void toggle(World world, boolean messaging) {
        this.toggle();

        if (this.isEnabled()) {
            ChunkShader customChunkShader = new ChunkShader(
                    Identifier.of("europa_client", "shaders/chunk.vert.glsl"),
                    Identifier.of("europa_client", "shaders/chunk.frag.glsl")
            );
            ChunkShader customWaterShader = new ChunkShader(
                    Identifier.of("europa_client", "shaders/chunk-water.vert.glsl"),
                    Identifier.of("europa_client", "shaders/chunk-water.frag.glsl")
            );
            ChunkShader.DEFAULT_BLOCK_SHADER = customChunkShader;
            ChunkShader.WATER_BLOCK_SHADER = customWaterShader;
        } else {
            ChunkShader.initChunkShaders();
        }

        GameShader.reloadAllShaders();

        // Rebuild all chunk meshes.
        for (Zone zone : world.getZones()) {
            for (Region region : zone.getRegions()) {
                for (Chunk chunk : region.getChunks()) {
                    if (chunk.getMeshGroup() != null) {
                        chunk.getMeshGroup().dispose();
                    }
                    chunk.setMeshGroup(null);
                    GameSingletons.zoneRenderer.addChunk(chunk);
                    chunk.flagForRemeshing(true);
                }
            }
        }

        GameSingletons.meshGenThread.meshChunks(GameSingletons.zoneRenderer);

        if (this.isEnabled() && messaging)
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Fullbright enabled");
        else
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Fullbright disabled");
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/mixins/GameSingletonsInterface.java:
```java
package dev.neuxs.europa_client.mixins;

import finalforeach.cosmicreach.GameSingletons;
import finalforeach.cosmicreach.accounts.Account;
import finalforeach.cosmicreach.entities.player.Player;
import java.util.WeakHashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(GameSingletons.class)
public interface GameSingletonsInterface {
    @Accessor("playersToAccounts")
    static WeakHashMap<Player, Account> getPlayersToAccounts() {
        throw new AssertionError();
    }
}

```

### ./nocheat/common/src/main/java/dev/neuxs/europa_client/mixins/ChatMenuMixin.java:
```java
package dev.neuxs.europa_client.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import finalforeach.cosmicreach.gamestates.ChatMenu;
import finalforeach.cosmicreach.chat.Chat;
import finalforeach.cosmicreach.accounts.Account;
import finalforeach.cosmicreach.networking.client.ChatSender;
import dev.neuxs.europa_client.commands.ClientCommandManager;

@Mixin(ChatMenu.class)
public abstract class ChatMenuMixin {

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lfinalforeach/cosmicreach/networking/client/ChatSender;sendMessageOrCommand(Lfinalforeach/cosmicreach/chat/Chat;Lfinalforeach/cosmicreach/accounts/Account;Ljava/lang/String;)V"
            )
    )
    private static void interceptSendMessageOrCommand(Chat chat, Account account, String messageText) {
        if (messageText.startsWith("#")) {
            ClientCommandManager.triggerCommand(account, messageText);
        } else {
            ChatSender.sendMessageOrCommand(chat, account, messageText);
        }
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lfinalforeach/cosmicreach/chat/Chat;addMessage(Lfinalforeach/cosmicreach/accounts/Account;Ljava/lang/String;)V"
            )
    )
    private void interceptAddMessage(Chat instance, Account account, String messageText) {
        if (messageText.startsWith("#")) {
            return;
        }
        instance.addMessage(account, messageText);
    }
}

```

### ./nocheat/common/src/main/resources/europa_client.mixins.json:
```json
{
  "required": true,
  "minVersion": "0.8",
  "package": "dev.neuxs.europa_client.mixins",
  "compatibilityLevel": "JAVA_17",
  "mixins": [
    "ChatMenuMixin",
    "GameSingletonsInterface"
  ],
  "client": [
  ],
  "injectors": {
    "defaultRequire": 1
  }
}
```

### ./nocheat/common/src/main/resources/assets/europa_client/shaders/chunk-water.vert.glsl:
```glsl
#version 150

in vec4 a_lighting;
uniform vec3 u_batchPosition;
uniform mat4 u_projViewTrans;
uniform mat4 u_modelMat;

uniform float u_time;
uniform vec3 cameraPosition;

uniform bool u_isItem = false;

out vec2 v_texCoord0;
out vec4 blocklight;
out float waveStrength;
out vec3 worldPos;
out vec3 toCameraVector;

#import "base:shaders/common/bitUnpacker.glsl"

void main()
{
    worldPos = GET_BLOCK_VERT_POSITION + u_batchPosition;

    vec3 trueWorldPos = worldPos + cameraPosition;
    if(u_isItem)
    {
        trueWorldPos = vec3(0.0);
    }

    blocklight = vec4(1.0);

    v_texCoord0 = GET_TEX_COORDS;

    toCameraVector = cameraPosition - trueWorldPos;
    vec3 normal = GET_VERT_NORMAL;

    float xOff = 0.0;
    float zOff = 0.0;
    if(normal.y < 0.0)
    {
        xOff = normal.x * -0.001;
        zOff = normal.z * -0.001;
    }
    float waveSpeed = 0.25;
    float waveTime = waveSpeed * u_time;
    float scale = 5.0;
    float wavePositionA = 10.0 * (cos(trueWorldPos.x * scale) +
    sin(trueWorldPos.z * scale));
    float wavePositionB = 10.0 * (sin(trueWorldPos.x * scale) +
    cos(trueWorldPos.z * scale));

    waveStrength = 0.1 * (sin(waveTime + wavePositionA) *
    cos(waveTime + wavePositionB));

    vec4 modelPosition = u_modelMat * vec4(worldPos.x + xOff,
    worldPos.y + waveStrength - 0.2,
    worldPos.z + zOff, 1.0);
    gl_Position = u_projViewTrans * modelPosition;

    modelPosition = u_modelMat * vec4(cameraPosition, 1.0);
    worldPos = trueWorldPos;
}

```

### ./nocheat/common/src/main/resources/assets/europa_client/shaders/chunk.frag.glsl:
```glsl
#version 150
#ifdef GL_ES
precision mediump float;
#endif

uniform vec3 cameraPosition;
uniform vec3 skyAmbientColor;
uniform vec4 tintColor;
uniform vec3 worldAmbientColor;

#import "base:shaders/common/renderDistance.glsl"

in vec2 v_texCoord0;
in vec3 worldPos;
in vec4 blocklight;
in vec3 faceNormal;

uniform sampler2D texDiffuse;
uniform vec3 u_sunDirection;

out vec4 outColor;
uniform float u_fogDensity;

#import "base:shaders/common/fog.glsl"

void main()
{
    vec2 tilingTexCoords = v_texCoord0;
    vec4 texColor = texture(texDiffuse, v_texCoord0);

    float fadeOutDistance = (u_renderDistanceInChunks - 1) * 16.0;
    float fadeOutFactor = clamp((fadeOutDistance - length(worldPos.xz -
    cameraPosition.xz)) / 16.0, 0.0, 1.0);
    texColor.a *= pow(fadeOutFactor, 0.5);

    if(texColor.a == 0.0)
    {
        discard;
    }

    vec3 lightTint = vec3(1.0);

    outColor = tintColor * vec4(texColor.rgb * lightTint, texColor.a);

    vec3 fogColor = skyAmbientColor;
    fogColor = getFogColor(fogColor, vec3(1.0), u_fogDensity, worldPos,
    cameraPosition);
    outColor.rgb = applyFog(fogColor, outColor.rgb, u_fogDensity, worldPos,
    cameraPosition);

    outColor.rgb = max(outColor.rgb, texColor.rgb);

    float gamma = 1.0;
    outColor.rgb = pow(outColor.rgb, vec3(1.0 / gamma));
}

```

### ./nocheat/common/src/main/resources/assets/europa_client/shaders/chunk.vert.glsl:
```glsl
#version 150

in vec4 a_lighting;
uniform vec3 u_batchPosition;
uniform mat4 u_projViewTrans;
uniform mat4 u_modelMat;
uniform vec3 cameraPosition;

out vec2 v_texCoord0;
out vec3 worldPos;
out vec4 blocklight;
out vec3 faceNormal;

#import "base:shaders/common/bitUnpacker.glsl"

void main()
{
	worldPos = GET_BLOCK_VERT_POSITION + u_batchPosition;
	vec3 trueWorldPos = worldPos + cameraPosition;

	blocklight = vec4(1.0);

	v_texCoord0 = GET_TEX_COORDS;
	faceNormal = GET_FACE_NORMAL;

	vec4 modelPosition = u_modelMat * vec4(worldPos, 1.0);
	worldPos = modelPosition.xyz;
	gl_Position = u_projViewTrans * modelPosition;

	modelPosition = u_modelMat * vec4(trueWorldPos, 1.0);
	worldPos = modelPosition.xyz;
}

```

### ./nocheat/common/src/main/resources/assets/europa_client/shaders/chunk-water.frag.glsl:
```glsl
#version 150
#ifdef GL_ES
precision mediump float;
#endif

uniform float u_time;
uniform vec3 cameraPosition;
uniform vec3 skyAmbientColor;
uniform vec3 skyColor;
uniform vec4 tintColor;
uniform vec3 worldAmbientColor;
uniform vec3 u_sunDirection;

#import "base:shaders/common/renderDistance.glsl"

in vec2 v_texCoord0;
in vec4 blocklight;
in float waveStrength;
in vec3 worldPos;
in vec3 toCameraVector;

uniform sampler2D texDiffuse;
uniform sampler2D noiseTex;

out vec4 outColor;

uniform float u_fogDensity;
#import "base:shaders/common/fog.glsl"

void main()
{
    vec2 numTiles = floor(v_texCoord0);
    vec2 tilingTexCoords = v_texCoord0;

    if(numTiles.xy != vec2(0.0, 0.0))
    {
        tilingTexCoords = (v_texCoord0 - numTiles);
        vec2 flooredTexCoords = floor((v_texCoord0 - numTiles) * 16.0) / 16.0;
        numTiles = numTiles + vec2(1.0, 1.0);
        tilingTexCoords = flooredTexCoords +
        mod(((tilingTexCoords - flooredTexCoords) * numTiles) * 16.0, 1.0)
        / 16.0;
    }

    vec4 texColor = texture(texDiffuse, tilingTexCoords);

    float fadeOutDistance = (u_renderDistanceInChunks - 1) * 16.0;
    float fadeOutFactor = clamp((fadeOutDistance - length(worldPos.xz -
    cameraPosition.xz)) / 16.0, 0.0, 1.0);
    float alpha = texColor.a * pow(fadeOutFactor, 0.5);
    if(alpha == 0.0)
    {
        discard;
    }

    vec3 waterColor = texColor.rgb;
    vec3 lightTint = vec3(1.0);

    outColor = tintColor * vec4(waterColor * lightTint, alpha);

    vec3 fogColor = vec3(1.0) - pow(vec3(1.0) - skyAmbientColor, vec3(2.0));
    fogColor = getFogColor(fogColor, vec3(1.0), u_fogDensity, worldPos,
    cameraPosition);
    outColor.rgb = applyFog(fogColor, outColor.rgb, u_fogDensity, worldPos,
    cameraPosition);

    outColor.rgb = max(outColor.rgb, texColor.rgb);

    float gamma = 1.0;
    outColor.rgb = pow(outColor.rgb, vec3(1.0 / gamma));
}

```

### ./nocheat/quilt/build.gradle:
```gradle
plugins {
    id "application"
    id "maven-publish"
    id "cosmicloom"
}


loom {

}

repositories {
    ivy {
        name "Cosmic Reach"
        url "https://github.com/CRModders/CosmicArchive/raw/main/versions"
        patternLayout {
            artifact "[classifier]/[revision]/client/Cosmic-Reach-[revision].jar"
        }
        metadataSources {
            artifact()
        }
        content {
            includeModule "finalforeach", "cosmicreach"
        }
    }
    maven {
        name "JitPack"
        url "https://jitpack.io"
    }
    maven {
        name "Quilt"
        url "https://maven.quiltmc.org/repository/release"
    }
    maven {
        name "Fabric"
        url "https://maven.fabricmc.net/"
    }
    maven {
        name "Sponge"
        url "https://repo.spongepowered.org/maven/"
    }
    mavenCentral()
}

configurations {
    cosmicreach
    compileOnly.extendsFrom(cosmicreach)

    internal {
        visible = false
        canBeConsumed = false
        canBeResolved = false
    }
    compileClasspath.extendsFrom(internal)
    runtimeClasspath.extendsFrom(internal)
    testCompileClasspath.extendsFrom(internal)
    testRuntimeClasspath.extendsFrom(internal)
}

dependencies {
    // Cosmic Reach
    cosmicReach(loom.cosmicReachClient("alpha", cosmic_reach_version))
    cosmicReachServer(loom.cosmicReachServer("alpha", cosmic_reach_version))

    // Cosmic Quilt
    modImplementation(loom.cosmicQuilt(cosmic_quilt_version))

    // Depend on the common module for shared code.
    implementation project(":nocheat:common")
}

tasks.withType(JavaCompile).configureEach {
    source(project(":nocheat:common").sourceSets.main.allSource)
}

tasks.withType(Javadoc).configureEach {
    source(project(":nocheat:common").sourceSets.main.allJava)
}

processResources {
    from project(":nocheat:common").sourceSets.main.resources
    def resourceTargets = [ "quilt.mod.json" ]
    def replaceProperties = [
            mod_version      : project.version,
            mod_group        : project.group,
            mod_description  : project.description,
            mod_name         : project.name,
            mod_id           : rootProject.property("id")
    ]

    inputs.properties replaceProperties
    replaceProperties.put("project", project)
    filesMatching(resourceTargets) {
        expand replaceProperties
    }
}

application {
    mainClass = "org.quiltmc.loader.impl.launch.knot.KnotClient"
}

applicationDefaultJvmArgs = [
        "-Dloader.development=true",
        "-Dloader.gameJarPath=" + configurations.cosmicreach.asPath
]

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

jar {
    archiveFileName.set("${rootProject.name}-quilt-${project.version}-nocheat.jar")
}
```

### ./nocheat/quilt/src/main/java/dev/neuxs/europa_client/QuiltClient.java:
```java
package dev.neuxs.europa_client;

import dev.crmodders.cosmicquilt.api.entrypoint.ModInitializer;
import org.quiltmc.loader.api.ModContainer;

public class QuiltClient implements ModInitializer {
	@Override
	public void onInitialize(ModContainer mod) {
		Client.init();
	}
}

```

### ./nocheat/quilt/src/main/resources/quilt.mod.json:
```json
{
  "schema_version": 1,

  "quilt_loader": {
    "group": "${mod_group}",
    "id": "${mod_id}",
    "version": "${mod_version}",

    "intermediate_mappings":"net.fabricmc:intermediary",

    "metadata": {
      "name": "Europa Client No-Cheat",
      "description": "${mod_description}",
      "contributors": {
        "Neuxs": "Owner"
      },

      "license": "MIT",

      "contact": {
        "homepage": "https://neuxs.dev/",
        "issues": "https://github.com/Neuxs0/Europa-Client/issues",
        "sources": "https://github.com/Neuxs0/Europa-Client"
      },

      "icon": "assets/${mod_id}/icon.png"
    },

    "entrypoints": {
      "init": "${mod_group}.${mod_id}.QuiltClient"
    },

    "depends": [
      {
        "id": "cosmicquilt",
        "versions": "*"
      },
      {
        "id": "cosmicreach",
        "versions": ">= 0.4.2"
      }
    ]
  },

  "mixin": [
    "${mod_id}.mixins.json"
  ]
}

```

### ./nocheat/puzzle/build.gradle:
```gradle
plugins {
    id "java"
    id "jigsaw"
    id "com.github.johnrengelman.shadow"
}

loom {
    splitEnvironmentSourceSets()
    mods {
        "SimplyShaders" {
            sourceSet sourceSets.main
            sourceSet sourceSets.client
        }
    }
    accessWidenerPath = file("src/main/resources/${id}.manipulator")
}

repositories {
    mavenCentral()
    maven {
        url "https://jitpack.io"
    }
}

dependencies {
    // Referencing a Cosmic Reach dependency using the version from gradle.properties.
    cosmicReach("finalforeach:cosmicreach-alpha:${property("cosmic_reach_version")}")

    // Depend on the common module containing shared code.
    implementation project(":nocheat:common")
}

tasks.named("compileClientJava") {
    source(project(":nocheat:common").sourceSets.main.allSource)
}

tasks.named("compileClientJava") {
    source(project(":nocheat:common").sourceSets.main.allJava)
}

processResources {
    def resourceTargets = ["puzzle.mod.json"]
    def replaceProperties = [
            mod_version     : project.version,
            mod_group       : project.group,
            mod_description : project.description,
            mod_name        : project.name,
            mod_id          : rootProject.property("id")
    ]

    inputs.properties replaceProperties
    replaceProperties.put("project", project)
    filesMatching(resourceTargets) {
        expand replaceProperties
    }
}

jar {
    archiveFileName.set("${rootProject.name}-puzzle-${project.version}-nocheat.jar")
}

// New task to copy europa_client.mixins.json from the common module.
tasks.register("copyMixins", Copy) {
    from(file("../nocheat/common/src/main/resources/europa_client.mixins.json"))
    into(file("src/client/resources"))
    // Declaring the output directory helps Gradle with up-to-date checks.
    outputs.dir file("src/client/resources")
}

// Make sure processClientResources waits for the copyMixins task.
tasks.named("processClientResources") {
    dependsOn tasks.named("copyMixins")
}

// Optionally, if the jar task also relies on the copied file, ensure it depends on copyMixins.
jar.dependsOn(tasks.named("copyMixins"))

```

### ./nocheat/puzzle/src/main/resources/europa_client.manipulator:
```manipulator

```

### ./nocheat/puzzle/src/main/resources/puzzle.mod.json:
```json
{
  "formatVersion": 1,
  "group": "${mod_group}",
  "id": "${mod_id}",
  "version": "${mod_version}",
  "name": "Europa Client No-Cheat",
  "description": "${mod_description}",
  "authors": [
    "Neuxs"
  ],
  "license": "MIT",
  "meta": {
    "icon": "${mod_id}:icons/icon.png"
  },
  "entrypoints": {
    "client_init": [
      "${mod_group}.${mod_id}.PuzzleClient"
    ]
  },
  "mixins": [
    "${mod_id}.mixins.json"
  ],
  "depends": {
    "cosmic-reach": ">=0.4.2",
    "puzzle-loader": ">=2.3.7"
  },
  "accessTransformers": [
    "${mod_id}.manipulator"
  ]
}
```

### ./nocheat/puzzle/src/client/java/dev/neuxs/europa_client/PuzzleClient.java:
```java
package dev.neuxs.europa_client;

import com.github.puzzle.core.loader.launch.provider.mod.entrypoint.impls.ClientModInitializer;

public class PuzzleClient implements ClientModInitializer {
    @Override
    public void onInit() {
        Client.init();
    }
}
```

### ./nocheat/puzzle/src/client/resources/europa_client.mixins.json:
```json
{
  "required": true,
  "minVersion": "0.8",
  "package": "dev.neuxs.europa_client.mixins",
  "compatibilityLevel": "JAVA_17",
  "mixins": [
    "UIMixin",
    "EntityMixin",
    "ChatMenuMixin",
    "YouDiedMenuMixin",
    "NoClipPacketMixin",
    "GameSingletonsInterface"
  ],
  "client": [
  ],
  "injectors": {
    "defaultRequire": 1
  }
}
```

### ./full/common/build.gradle:
```gradle
plugins {
    id 'java'
    id "cosmicloom"
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

loom {

}

repositories {
    mavenCentral()
}

dependencies {
    cosmicReach(loom.cosmicReachClient("alpha", cosmic_reach_version))
    cosmicReachServer(loom.cosmicReachServer("alpha", cosmic_reach_version))
    modImplementation(loom.cosmicQuilt(cosmic_quilt_version))
    implementation "com.google.code.gson:gson:2.8.9"
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/Client.java:
```java
package dev.neuxs.europa_client;

import dev.neuxs.europa_client.commands.ClientCommandRegistry;
import dev.neuxs.europa_client.modules.Modules;
import dev.neuxs.europa_client.utils.InputManager;
import dev.neuxs.europa_client.utils.SyncModules;
import finalforeach.cosmicreach.chat.Chat;
import finalforeach.cosmicreach.chat.IChat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Client {
    public static final String MOD_ID = "europa_client";
    public static final String MOD_NAME = "Europa Client";
    public static Logger LOGGER = LoggerFactory.getLogger("EuropaClient");
    public static String VERSION = "1.2.0";
    public static boolean playerDied = false;
    public static IChat clientChat = Chat.MAIN_CLIENT_CHAT;

    public static void init() {
        LOGGER.info("Europa Client Initializing...");

        Modules.initModules();
        ClientCommandRegistry.registerClientCommands();

        LOGGER.info("Europa Client Initialized!");
    }

    public static void render() {
        SyncModules.Sync();
        InputManager.Keybinds();
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/ClientCommandRegistry.java:
```java
package dev.neuxs.europa_client.commands;

import dev.neuxs.europa_client.commands.misc.HelpCommand;
import dev.neuxs.europa_client.commands.misc.SayCommand;
import dev.neuxs.europa_client.commands.misc.TypeCommand;
import dev.neuxs.europa_client.commands.misc.VersionCommand;
import dev.neuxs.europa_client.commands.modules.cheats.NoClipCommand;
import dev.neuxs.europa_client.commands.modules.cheats.ReachCommand;
import dev.neuxs.europa_client.commands.modules.cheats.SpeedCommand;
import dev.neuxs.europa_client.commands.utils.DisconnectCommand;
import dev.neuxs.europa_client.commands.modules.utils.FullbrightCommand;
import dev.neuxs.europa_client.commands.utils.PlayerListCommand;
import dev.neuxs.europa_client.commands.utils.QuitGameCommand;

public class ClientCommandRegistry {
    public static void registerClientCommands() {
        // Misc
        ClientCommandManager.registerCommand("say", SayCommand::new);
        ClientCommandManager.registerCommand("help", HelpCommand::new, "?", "h");
        ClientCommandManager.registerCommand("type", TypeCommand::new, "clientType");
        ClientCommandManager.registerCommand("version", VersionCommand::new, "clientVersion");

        // Utils
        ClientCommandManager.registerCommand("disconnect", DisconnectCommand::new, "dc", "quit", "exit");
        ClientCommandManager.registerCommand("quitGame", QuitGameCommand::new, "gameQuit", "closeGame", "exitGame");
        ClientCommandManager.registerCommand("playerList", PlayerListCommand::new, "pl");

        // Modules - Utils
        ClientCommandManager.registerCommand("fullbright", FullbrightCommand::new, "fb");

        // Modules - Cheats
        ClientCommandManager.registerCommand("noclip", NoClipCommand::new, "nc");
        ClientCommandManager.registerCommand("speed", SpeedCommand::new, "s");
        ClientCommandManager.registerCommand("reach", ReachCommand::new);
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/ClientCommand.java:
```java
package dev.neuxs.europa_client.commands;

import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.accounts.Account;

public abstract class ClientCommand {
    protected Account account;
    protected String[] args;

    public ClientCommand() {}

    public void setup(Account account, String[] args) {
        this.account = account;
        this.args = args;
    }

    public abstract void run();

    public abstract String getDescription();
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/ClientCommandManager.java:
```java
package dev.neuxs.europa_client.commands;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import dev.neuxs.europa_client.Client;
import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.accounts.Account;

public class ClientCommandManager {

    private static final Map<String, Supplier<ClientCommand>> COMMANDS =
            new HashMap<>();
    private static final Map<String, Supplier<ClientCommand>> ALIASES =
            new HashMap<>();

    public static void registerCommand(
            String name,
            Supplier<ClientCommand> supplier,
            String... aliases
    ) {
        name = name.toLowerCase();
        if (COMMANDS.containsKey(name)) {
            System.err.println("ClientCommand `" + name + "` already registered!");
        }
        COMMANDS.put(name, supplier);

        for (String alias : aliases) {
            alias = alias.toLowerCase();
            if (COMMANDS.containsKey(alias) || ALIASES.containsKey(alias)) {
                System.err.println("Alias `" + alias + "` already registered!");
            } else {
                ALIASES.put(alias, supplier);
            }
        }
    }

    public static void triggerCommand(
            Account account,
            String messageText
    ) {
        String withoutPrefix = messageText.substring(1);

        String[] args;
        String commandStr;
        if (withoutPrefix.toLowerCase().startsWith("say ")) {
            commandStr = "say";
            String rest = withoutPrefix.substring(4);
            args = new String[]{commandStr, rest};
        } else {
            String[] parts = withoutPrefix.split(" ");
            commandStr = parts[0].toLowerCase();
            args = withoutPrefix.split(" ");
        }

        Supplier<ClientCommand> supplier = COMMANDS.get(commandStr);
        if (supplier == null) {
            supplier = ALIASES.get(commandStr);
        }
        if (supplier == null) {
            Client.clientChat.addMessage(null, "Unknown command: " + commandStr);
            return;
        }
        ClientCommand command = supplier.get();
        command.setup(account, args);
        try {
            command.run();
        } catch (Exception e) {
            Client.clientChat.addMessage(null, "Error running command: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void printHelp(IChat chat) {
        StringBuilder sb = new StringBuilder("Available commands:\n");
        for (String cmd : COMMANDS.keySet()) {
            Supplier<ClientCommand> supplier = COMMANDS.get(cmd);
            ClientCommand command = supplier.get();
            sb.append("#")
                    .append(cmd)
                    .append(" - ")
                    .append(command.getDescription())
                    .append("\n");
        }
        Client.clientChat.addMessage(null, sb.toString());
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/misc/HelpCommand.java:
```java
package dev.neuxs.europa_client.commands.misc;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.commands.ClientCommandManager;

public class HelpCommand extends ClientCommand {

    @Override
    public void run() {
        ClientCommandManager.printHelp(Client.clientChat);
    }

    @Override
    public String getDescription() {
        return "Displays help information for all Europa Client commands.";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/misc/SayCommand.java:
```java
package dev.neuxs.europa_client.commands.misc;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;

public class SayCommand extends ClientCommand {

    @Override
    public void run() {
        if (args.length < 2 || args[1].trim().isEmpty()) {
            Client.clientChat.addMessage(null, "Usage: #say <message>");
            return;
        }

        String message = args[1].trim();
        Client.clientChat.addMessage(account, message);
    }

    @Override
    public String getDescription() {
        return "Sends a public chat message.";
    }
}
```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/misc/VersionCommand.java:
```java
package dev.neuxs.europa_client.commands.misc;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.utils.Chat;

public class VersionCommand extends ClientCommand {

    @Override
    public void run() {
        Client.clientChat.addMessage(null, Chat.getClientPrefix() + "You are running Europa Client v" + Client.VERSION);
    }

    @Override
    public String getDescription() {
        return "Tells you what version of Europa Client you are running.";
    }
}
```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/misc/TypeCommand.java:
```java
package dev.neuxs.europa_client.commands.misc;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.utils.Chat;

public class TypeCommand extends ClientCommand {

    @Override
    public void run() {
        Client.clientChat.addMessage(null, Chat.getClientPrefix() + "You are running the full Europa Client.");
    }

    @Override
    public String getDescription() {
        return "Tells you what type of Europa Client you are running.";
    }
}
```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/utils/PlayerListCommand.java:
```java
package dev.neuxs.europa_client.commands.utils;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.mixins.GameSingletonsInterface;
import dev.neuxs.europa_client.utils.Chat;
import finalforeach.cosmicreach.accounts.Account;
import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.entities.player.Player;
import java.util.WeakHashMap;

public class PlayerListCommand extends ClientCommand {

    @Override
    public void run() {
        WeakHashMap<Player, Account> playersToAccounts =
                GameSingletonsInterface.getPlayersToAccounts();

        if (playersToAccounts == null || playersToAccounts.isEmpty()) {
            Client.clientChat.addMessage(null,
                    Chat.getClientPrefix() + "No players online.");
            return;
        }

        StringBuilder playerList = new StringBuilder();
        int count = 0;
        for (Account account : playersToAccounts.values()) {
            if (count > 0) {
                playerList.append(", ");
            }
            playerList.append(account.getDisplayName());
            count++;
        }

        if (count == 1) {
            Client.clientChat.addMessage(null,
                    Chat.getClientPrefix() + "You are the only player online!");
        } else {
            Client.clientChat.addMessage(null,
                    Chat.getClientPrefix() + "Online players: " + playerList);
        }
    }

    @Override
    public String getDescription() {
        return "Shows all the online players on the server.";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/utils/QuitGameCommand.java:
```java
package dev.neuxs.europa_client.commands.utils;

import com.badlogic.gdx.Gdx;
import dev.neuxs.europa_client.commands.ClientCommand;
import finalforeach.cosmicreach.GameSingletons;
import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.gamestates.*;
import finalforeach.cosmicreach.io.ChunkSaver;
import finalforeach.cosmicreach.networking.client.ClientNetworkManager;

public class QuitGameCommand extends ClientCommand {

    @Override
    public void run() {
        Gdx.app.postRunnable(() -> {
            if (Gdx.input.isCursorCatched()) Gdx.input.setCursorCatched(false);

            if (GameSingletons.isHost) {
                ChunkSaver.saveWorld(InGame.getWorld());
            } else {
                try {
                    ClientNetworkManager.CLIENT.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            GameState.switchToGameState(InGame.IN_GAME);
            GameState.switchToGameState(new MainMenu());
            System.exit(0);
        });
    }

    @Override
    public String getDescription() {
        return "Closes the game quickly and safely.";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/utils/DisconnectCommand.java:
```java
package dev.neuxs.europa_client.commands.utils;

import com.badlogic.gdx.Gdx;
import dev.neuxs.europa_client.commands.ClientCommand;
import finalforeach.cosmicreach.GameSingletons;
import finalforeach.cosmicreach.chat.IChat;
import finalforeach.cosmicreach.gamestates.*;
import finalforeach.cosmicreach.io.ChunkSaver;
import finalforeach.cosmicreach.networking.client.ClientNetworkManager;

public class DisconnectCommand extends ClientCommand {

    @Override
    public void run() {
        Gdx.app.postRunnable(() -> {
            if (Gdx.input.isCursorCatched()) Gdx.input.setCursorCatched(false);

            if (GameSingletons.isHost) {
                ChunkSaver.saveWorld(InGame.getWorld());
            } else {
                try {
                    ClientNetworkManager.CLIENT.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            GameState.switchToGameState(InGame.IN_GAME);
            GameState.switchToGameState(new MainMenu());
        });
    }

    @Override
    public String getDescription() {
        return "Disconnects yourself from the server.";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/modules/utils/FullbrightCommand.java:
```java
package dev.neuxs.europa_client.commands.modules.utils;

import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.modules.Modules;
import finalforeach.cosmicreach.gamestates.InGame;

public class FullbrightCommand extends ClientCommand {
    @Override
    public void run() {
        Modules.fullbright.toggle(InGame.getWorld(), true);
    }

    @Override
    public String getDescription() {
        return "Toggles fullbright.";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/modules/cheats/ReachCommand.java:
```java
package dev.neuxs.europa_client.commands.modules.cheats;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.modules.Modules;
import dev.neuxs.europa_client.utils.Chat;

public class ReachCommand extends ClientCommand {

    @Override
    public void run() {
        if (args.length == 1) {
            Modules.reach.toggle(true);
            return;
        }

        // If additional arguments are provided, check for setting speed.
        // Expected format: "#reach set speed <value>"
        if (args.length >= 4 && args[1].equalsIgnoreCase("set") &&
                args[2].equalsIgnoreCase("distance")) {

            try {
                float reachValue = Float.parseFloat(args[3].trim());

                if (Float.isNaN(reachValue) || Float.isInfinite(reachValue)) {
                    Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Invalid distance value, please provide a finite number.");
                    return;
                }

                Modules.reach.setReachDistance(reachValue);
            } catch (NumberFormatException ex) {
                Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Invalid number format. Use a valid float value.");
            }
        } else {
            Client.clientChat.addMessage(null, "Usage: #reach OR #reach set distance <value>");
        }
    }

    @Override
    public String getDescription() {
        return "Toggles reach cheat. Use '#reach set distance <value>' to set the reach distance.";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/modules/cheats/SpeedCommand.java:
```java
package dev.neuxs.europa_client.commands.modules.cheats;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.modules.Modules;
import dev.neuxs.europa_client.utils.Chat;

public class SpeedCommand extends ClientCommand {

    @Override
    public void run() {
        if (args.length == 1) {
            Modules.speed.toggle(true);
            return;
        }

        // If additional arguments are provided, check for setting speed.
        // Expected format: "#speed set speed <value>"
        if (args.length >= 4 && args[1].equalsIgnoreCase("set") &&
                args[2].equalsIgnoreCase("speed")) {

            try {
                float speedValue = Float.parseFloat(args[3].trim());

                if (Float.isNaN(speedValue) || Float.isInfinite(speedValue)) {
                    Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Invalid speed value, please provide a finite number.");
                    return;
                }

                Modules.speed.setSpeed(speedValue);
            } catch (NumberFormatException ex) {
                Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Invalid number format. Use a valid float value.");
            }
        } else {
            Client.clientChat.addMessage(null, "Usage: #speed OR #speed set speed <value>");
        }
    }

    @Override
    public String getDescription() {
        return "Toggles speed cheat. Use '#speed set speed <value>' to set the speed.";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/commands/modules/cheats/NoClipCommand.java:
```java
package dev.neuxs.europa_client.commands.modules.cheats;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.commands.ClientCommand;
import dev.neuxs.europa_client.modules.Modules;
import dev.neuxs.europa_client.utils.Chat;

public class NoClipCommand extends ClientCommand {

    @Override
    public void run() {
        if (args.length == 1) {
            Modules.noClip.toggle(true);
            return;
        }

        // If additional arguments are provided, check for setting speed.
        // Expected format: "#noclip set speed <value>"
        if (args.length >= 4 && args[1].equalsIgnoreCase("set") &&
                args[2].equalsIgnoreCase("speed")) {

            try {
                float speedValue = Float.parseFloat(args[3].trim());

                if (Float.isNaN(speedValue) || Float.isInfinite(speedValue)) {
                    Client.clientChat.addMessage(null,
                            Chat.getClientPrefix() +
                                    "Invalid speed value, please provide a finite number.");
                    return;
                }

                Modules.noClip.setSpeed(speedValue);
            } catch (NumberFormatException ex) {
                Client.clientChat.addMessage(null,
                        Chat.getClientPrefix() +
                                "Invalid number format. Use a valid float value.");
            }
        } else {
            Client.clientChat.addMessage(null,
                    "Usage: #noclip OR #noclip set speed <value>");
        }
    }

    @Override
    public String getDescription() {
        return "Toggles no-clip mode. Use '#noclip set speed <value>' to set the speed.";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/utils/SyncModules.java:
```java
package dev.neuxs.europa_client.utils;

import dev.neuxs.europa_client.modules.Modules;
import finalforeach.cosmicreach.gamestates.InGame;

public class SyncModules {
    public SyncModules() {}

    public static void Sync() {
        // Sync no-clip
        if (InGame.getLocalPlayer().getEntity().isNoClip() != Modules.noClip.isEnabled()) {
            Modules.noClip.enable(false);
        }
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/utils/Chat.java:
```java
package dev.neuxs.europa_client.utils;

public class Chat {
    public static String getClientPrefix() {
        return "[Europa Client] ";
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/utils/InputManager.java:
```java
package dev.neuxs.europa_client.utils;

import com.badlogic.gdx.Gdx;
import dev.neuxs.europa_client.modules.Module;
import dev.neuxs.europa_client.modules.Modules;
import finalforeach.cosmicreach.gamestates.ChatMenu;
import finalforeach.cosmicreach.gamestates.GameState;

public class InputManager {
    public InputManager() {}

    public static void Keybinds() {
        // Do nothing if currently in the chat menu.
        if (GameState.currentGameState instanceof ChatMenu) {
            return;
        }
        // Loop through every module registered in the Modules list.
        for (Module module : Modules.moduleList) {
            int key = module.getKeyBind();
            // Immediately skip if the keybind is 0
            if (key == 0) {
                continue;
            }
            if (isFirstFrameKeyDown(key)) {
                // Each module should implement its own behavior on key press.
                module.toggle();
            }
        }
    }

    public static boolean isKeyDown(int keycode) {
        return Gdx.input.isKeyPressed(keycode);
    }

    public static boolean isKeyUp(int keycode) {
        return !Gdx.input.isKeyPressed(keycode);
    }

    public static boolean isFirstFrameKeyDown(int keycode) {
        return Gdx.input.isKeyJustPressed(keycode);
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/modules/Module.java:
```java
package dev.neuxs.europa_client.modules;

import dev.neuxs.europa_client.settings.Setting;

public abstract class Module {
    protected Setting<Integer> keyBindSetting;
    protected Setting<Boolean> enabledSetting;

    public Module(int defaultKeyBind, boolean defaultEnabled) {
        // No validator for a key (or you could add one if needed)
        this.keyBindSetting = new Setting<>("keybind", defaultKeyBind);
        this.enabledSetting = new Setting<>("enabled", defaultEnabled);
    }

    public void toggle() {
        this.enabledSetting.setValue(!this.enabledSetting.getValue());
    }

    public void enable() {
        this.enabledSetting.setValue(true);
    }

    public void disable() {
        this.enabledSetting.setValue(false);
    }

    public boolean isEnabled() {
        return this.enabledSetting.getValue();
    }

    public int getKeyBind() {
        return this.keyBindSetting.getValue();
    }

    public void setKeyBind(int keyBind) {
        this.keyBindSetting.setValue(keyBind);
    }
}
```

### ./full/common/src/main/java/dev/neuxs/europa_client/modules/Modules.java:
```java
package dev.neuxs.europa_client.modules;

import com.badlogic.gdx.Input;
import dev.neuxs.europa_client.modules.cheats.NoClip;
import dev.neuxs.europa_client.modules.cheats.Reach;
import dev.neuxs.europa_client.modules.cheats.Speed;
import dev.neuxs.europa_client.modules.utils.Fullbright;
import java.util.ArrayList;
import java.util.List;

public class Modules {
    // Example modules (for the full client version)
    public static Fullbright fullbright;
    public static NoClip noClip;
    public static Speed speed;
    public static Reach reach;

    // A central list of all modules
    public static List<Module> moduleList = new ArrayList<>();

    public static void initModules() {
        // Create and register your modules.
        int fullbrightKeybind = Input.Keys.UNKNOWN;
        fullbright = new Fullbright(fullbrightKeybind, false);
        moduleList.add(fullbright);

        int noClipKeybind = Input.Keys.UNKNOWN;
        noClip = new NoClip(noClipKeybind, false);
        moduleList.add(noClip);

        int speedKeybind = Input.Keys.UNKNOWN;
        speed = new Speed(speedKeybind, false);
        moduleList.add(speed);

        int reachKeybind = Input.Keys.UNKNOWN;
        reach = new Reach(reachKeybind, false);
        moduleList.add(reach);
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/modules/utils/Fullbright.java:
```java
package dev.neuxs.europa_client.modules.utils;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.modules.Module;
import dev.neuxs.europa_client.utils.Chat;
import finalforeach.cosmicreach.GameSingletons;
import finalforeach.cosmicreach.rendering.shaders.ChunkShader;
import finalforeach.cosmicreach.rendering.shaders.GameShader;
import finalforeach.cosmicreach.util.Identifier;
import finalforeach.cosmicreach.world.Chunk;
import finalforeach.cosmicreach.world.Region;
import finalforeach.cosmicreach.world.World;
import finalforeach.cosmicreach.world.Zone;

public class Fullbright extends Module {

    public Fullbright(int keybind, boolean defaultEnabled) {
        super(keybind, defaultEnabled);
    }

    public void toggle(World world, boolean messaging) {
        this.toggle();

        if (this.isEnabled()) {
            ChunkShader customChunkShader = new ChunkShader(
                    Identifier.of("europa_client", "shaders/chunk.vert.glsl"),
                    Identifier.of("europa_client", "shaders/chunk.frag.glsl")
            );
            ChunkShader customWaterShader = new ChunkShader(
                    Identifier.of("europa_client", "shaders/chunk-water.vert.glsl"),
                    Identifier.of("europa_client", "shaders/chunk-water.frag.glsl")
            );
            ChunkShader.DEFAULT_BLOCK_SHADER = customChunkShader;
            ChunkShader.WATER_BLOCK_SHADER = customWaterShader;
        } else {
            ChunkShader.initChunkShaders();
        }

        GameShader.reloadAllShaders();

        // Rebuild all chunk meshes.
        for (Zone zone : world.getZones()) {
            for (Region region : zone.getRegions()) {
                for (Chunk chunk : region.getChunks()) {
                    if (chunk.getMeshGroup() != null) {
                        chunk.getMeshGroup().dispose();
                    }
                    chunk.setMeshGroup(null);
                    GameSingletons.zoneRenderer.addChunk(chunk);
                    chunk.flagForRemeshing(true);
                }
            }
        }

        GameSingletons.meshGenThread.meshChunks(GameSingletons.zoneRenderer);

        if (this.isEnabled() && messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Fullbright enabled");
        } else {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Fullbright disabled");
        }
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/modules/cheats/NoClip.java:
```java
package dev.neuxs.europa_client.modules.cheats;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.modules.Module;
import dev.neuxs.europa_client.settings.Setting;
import dev.neuxs.europa_client.utils.Chat;
import finalforeach.cosmicreach.entities.player.Player;
import finalforeach.cosmicreach.gamestates.InGame;

public class NoClip extends Module {
    private Setting<Float> speedSetting;

    public NoClip(int keybind, boolean defaultEnabled) {
        super(keybind, defaultEnabled);
        this.speedSetting = new Setting<>("speed", 1.0f, value -> value >= 0.1f && value <= Float.MAX_VALUE);
    }

    public void setNoClip(Player player, boolean noClip) {
        player.getEntity().setNoClip(noClip);
        if (noClip) {
            player.getEntity().velocity.setZero();
        }
    }

    public void setSpeed(float newSpeed) {
        this.speedSetting.setValue(newSpeed);
        Client.clientChat.addMessage(null, "No-clip speed set to " + this.speedSetting.getValue());
    }

    public float getSpeed() {
        return this.speedSetting.getValue();
    }

    public void toggle(boolean messaging) {
        this.toggle();
        setNoClip(InGame.getLocalPlayer(), this.isEnabled());
        String msg = this.isEnabled() ? "No-clip enabled" : "No-clip disabled";
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + msg);
        }
    }

    public void enable(boolean messaging) {
        this.enable();
        setNoClip(InGame.getLocalPlayer(), true);
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "No-clip enabled");
        }
    }

    public void disable(boolean messaging) {
        this.disable();
        setNoClip(InGame.getLocalPlayer(), false);
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "No-clip disabled");
        }
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/modules/cheats/Reach.java:
```java
package dev.neuxs.europa_client.modules.cheats;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.modules.Module;
import dev.neuxs.europa_client.settings.Setting;
import dev.neuxs.europa_client.utils.Chat;

public class Reach extends Module {
    // Create a Setting for reach distance with a default of 6.0, minimum 1.0, and an upper bound (e.g. Float.MAX_VALUE).
    private Setting<Float> distanceSetting;

    public Reach(int keybind, boolean defaultEnabled) {
        super(keybind, defaultEnabled);
        this.distanceSetting = new Setting<>("distance", 6.0f, value -> value >= 1.0f && value <= Float.MAX_VALUE);
    }

    public float getReachDistance() {
        return this.distanceSetting.getValue();
    }

    public void setReachDistance(float newDistance) {
        this.distanceSetting.setValue(newDistance);
        Client.clientChat.addMessage(null, "Reach set to " + this.distanceSetting.getValue());
    }

    public void toggle(boolean messaging) {
        this.toggle();
        String msg = this.isEnabled() ? "Reach enabled" : "Reach disabled";
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + msg);
        }
    }

    public void enable(boolean messaging) {
        this.enable();
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Reach enabled");
        }
    }

    public void disable(boolean messaging) {
        this.disable();
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Reach disabled");
        }
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/modules/cheats/Speed.java:
```java
package dev.neuxs.europa_client.modules.cheats;

import dev.neuxs.europa_client.Client;
import dev.neuxs.europa_client.modules.Module;
import dev.neuxs.europa_client.settings.Setting;
import dev.neuxs.europa_client.utils.Chat;

public class Speed extends Module {
    private Setting<Float> speedSetting;

    public Speed(int keybind, boolean defaultEnabled) {
        super(keybind, defaultEnabled);
        this.speedSetting = new Setting<>("speed", 1.5f, value -> value >= 0.1f && value <= Float.MAX_VALUE);
    }

    public float getSpeed() {
        return this.speedSetting.getValue();
    }

    public void setSpeed(float newSpeed) {
        this.speedSetting.setValue(newSpeed);
        Client.clientChat.addMessage(null, "Player speed set to " + this.speedSetting.getValue());
    }

    public void toggle(boolean messaging) {
        this.toggle();
        String msg = this.isEnabled() ? "Speed enabled" : "Speed disabled";
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + msg);
        }
    }

    public void enable(boolean messaging) {
        this.enable();
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Speed enabled");
        }
    }

    public void disable(boolean messaging) {
        this.disable();
        if (messaging) {
            Client.clientChat.addMessage(null, Chat.getClientPrefix() + "Speed disabled");
        }
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/mixins/GameSingletonsInterface.java:
```java
package dev.neuxs.europa_client.mixins;

import finalforeach.cosmicreach.GameSingletons;
import finalforeach.cosmicreach.accounts.Account;
import finalforeach.cosmicreach.entities.player.Player;
import java.util.WeakHashMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(GameSingletons.class)
public interface GameSingletonsInterface {
    @Accessor("playersToAccounts")
    static WeakHashMap<Player, Account> getPlayersToAccounts() {
        throw new AssertionError();
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/mixins/ChatMenuMixin.java:
```java
package dev.neuxs.europa_client.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import finalforeach.cosmicreach.gamestates.ChatMenu;
import finalforeach.cosmicreach.chat.Chat;
import finalforeach.cosmicreach.accounts.Account;
import finalforeach.cosmicreach.networking.client.ChatSender;
import dev.neuxs.europa_client.commands.ClientCommandManager;

@Mixin(ChatMenu.class)
public abstract class ChatMenuMixin {

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lfinalforeach/cosmicreach/networking/client/ChatSender;sendMessageOrCommand(Lfinalforeach/cosmicreach/chat/Chat;Lfinalforeach/cosmicreach/accounts/Account;Ljava/lang/String;)V"
            )
    )
    private static void interceptSendMessageOrCommand(Chat chat, Account account, String messageText) {
        if (messageText.startsWith("#")) {
            ClientCommandManager.triggerCommand(account, messageText);
        } else {
            ChatSender.sendMessageOrCommand(chat, account, messageText);
        }
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lfinalforeach/cosmicreach/chat/Chat;addMessage(Lfinalforeach/cosmicreach/accounts/Account;Ljava/lang/String;)V"
            )
    )
    private void interceptAddMessage(Chat instance, Account account, String messageText) {
        if (messageText.startsWith("#")) {
            return;
        }
        instance.addMessage(account, messageText);
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/mixins/YouDiedMenuMixin.java:
```java
package dev.neuxs.europa_client.mixins;

import dev.neuxs.europa_client.Client;
import finalforeach.cosmicreach.gamestates.YouDiedMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(YouDiedMenu.class)
public class YouDiedMenuMixin {
    @Inject(method = "create", at = @At("HEAD"))
    private void onCreate(CallbackInfo ci) {
        Client.playerDied = true;
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/mixins/UIMixin.java:
```java
package dev.neuxs.europa_client.mixins;

import dev.neuxs.europa_client.Client;
import finalforeach.cosmicreach.ui.UI;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(UI.class)
public class UIMixin {
    @Inject(method = "render", at = @At("TAIL"))
    public void render(CallbackInfo ci){
        Client.render();
    }
}
```

### ./full/common/src/main/java/dev/neuxs/europa_client/mixins/NoClipPacketMixin.java:
```java
package dev.neuxs.europa_client.mixins;

import dev.neuxs.europa_client.modules.Modules;
import finalforeach.cosmicreach.entities.player.Player;
import finalforeach.cosmicreach.networking.NetworkIdentity;
import finalforeach.cosmicreach.networking.packets.entities.NoClipPacket;
import io.netty.channel.ChannelHandlerContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(NoClipPacket.class)
public abstract class NoClipPacketMixin {

    @Shadow
    private boolean shouldNoClip;

    @Overwrite
    public void handle(NetworkIdentity identity, ChannelHandlerContext ctx) {
        Player player = identity.getPlayer();
        Modules.noClip.setNoClip(player, this.shouldNoClip);
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/mixins/EntityMixin.java:
```java
package dev.neuxs.europa_client.mixins;

import dev.neuxs.europa_client.modules.Modules;
import finalforeach.cosmicreach.entities.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(Entity.class)
public abstract class EntityMixin {

    @ModifyArg(
            method = "updatePositions(Lfinalforeach/cosmicreach/world/Zone;F)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/badlogic/gdx/math/Vector3;set(FFF)Lcom/badlogic/gdx/math/Vector3;",
                    ordinal = 0
            ),
            index = 0
    )
    private float modifyPosDiffX(float x) {
        Entity self = (Entity) (Object) this;
        float modifier = 1.0F;
        if (self.isNoClip()) {
            modifier *= Modules.noClip.getSpeed();
        }
        if (Modules.speed.isEnabled()) {
            modifier *= Modules.speed.getSpeed();
        }
        return x * modifier;
    }

    @ModifyArg(
            method = "updatePositions(Lfinalforeach/cosmicreach/world/Zone;F)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/badlogic/gdx/math/Vector3;set(FFF)Lcom/badlogic/gdx/math/Vector3;",
                    ordinal = 0
            ),
            index = 1
    )
    private float modifyPosDiffY(float y) {
        Entity self = (Entity) (Object) this;
        float modifier = 1.0F;
        if (self.isNoClip()) {
            modifier *= Modules.noClip.getSpeed();
        }
        return y * modifier;
    }

    @ModifyArg(
            method = "updatePositions(Lfinalforeach/cosmicreach/world/Zone;F)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/badlogic/gdx/math/Vector3;set(FFF)Lcom/badlogic/gdx/math/Vector3;",
                    ordinal = 0
            ),
            index = 2
    )
    private float modifyPosDiffZ(float z) {
        Entity self = (Entity) (Object) this;
        float modifier = 1.0F;
        if (self.isNoClip()) {
            modifier *= Modules.noClip.getSpeed();
        }
        if (Modules.speed.isEnabled()) {
            modifier *= Modules.speed.getSpeed();
        }
        return z * modifier;
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/mixins/BlockRaycastsMixin.java:
```java
package dev.neuxs.europa_client.mixins;

import dev.neuxs.europa_client.modules.Modules;
import finalforeach.cosmicreach.BlockRaycasts;
import finalforeach.cosmicreach.entities.player.Player;
import finalforeach.cosmicreach.items.ItemStack;
import finalforeach.cosmicreach.world.Zone;
import com.badlogic.gdx.math.collision.Ray;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockRaycasts.class)
public abstract class BlockRaycastsMixin {
    @Shadow
    private float maximumRaycastDist;

    @Inject(method = "raycast", at = @At("HEAD"))
    private void updateMaximumRaycastDistance(Zone zone, Ray ray, Player player,
                                              ItemStack heldItemStack,
                                              boolean breakPressed,
                                              boolean placePressed,
                                              CallbackInfo ci) {
        this.maximumRaycastDist = Modules.reach.getReachDistance();
    }
}

```

### ./full/common/src/main/java/dev/neuxs/europa_client/settings/Setting.java:
```java
package dev.neuxs.europa_client.settings;

import java.util.function.Predicate;

public class Setting<T> {
    private final String name;
    private final T defaultValue;
    private final Predicate<T> validator;
    private T value;

    public Setting(String name, T defaultValue) {
        this(name, defaultValue, t -> true);
    }

    public Setting(String name, T defaultValue, Predicate<T> validator) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.validator = validator;
        this.value = defaultValue;
    }

    public String getName() {
        return name;
    }

    public T getDefaultValue() {
        return defaultValue;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T newValue) {
        if (!validator.test(newValue)) {
            throw new IllegalArgumentException("Invalid value for setting " + name);
        }
        this.value = newValue;
    }
}

```

### ./full/common/src/main/resources/europa_client.mixins.json:
```json
{
  "required": true,
  "minVersion": "0.8",
  "package": "dev.neuxs.europa_client.mixins",
  "compatibilityLevel": "JAVA_17",
  "mixins": [
    "UIMixin",
    "EntityMixin",
    "ChatMenuMixin",
    "YouDiedMenuMixin",
    "NoClipPacketMixin",
    "BlockRaycastsMixin",
    "GameSingletonsInterface"
  ],
  "client": [
  ],
  "injectors": {
    "defaultRequire": 1
  }
}
```

### ./full/common/src/main/resources/assets/europa_client/shaders/chunk-water.vert.glsl:
```glsl
#version 150

in vec4 a_lighting;
uniform vec3 u_batchPosition;
uniform mat4 u_projViewTrans;
uniform mat4 u_modelMat;

uniform float u_time;
uniform vec3 cameraPosition;

uniform bool u_isItem = false;

out vec2 v_texCoord0;
out vec4 blocklight;
out float waveStrength;
out vec3 worldPos;
out vec3 toCameraVector;

#import "base:shaders/common/bitUnpacker.glsl"

void main()
{
    worldPos = GET_BLOCK_VERT_POSITION + u_batchPosition;

    vec3 trueWorldPos = worldPos + cameraPosition;
    if(u_isItem)
    {
        trueWorldPos = vec3(0.0);
    }

    blocklight = vec4(1.0);

    v_texCoord0 = GET_TEX_COORDS;

    toCameraVector = cameraPosition - trueWorldPos;
    vec3 normal = GET_VERT_NORMAL;

    float xOff = 0.0;
    float zOff = 0.0;
    if(normal.y < 0.0)
    {
        xOff = normal.x * -0.001;
        zOff = normal.z * -0.001;
    }
    float waveSpeed = 0.25;
    float waveTime = waveSpeed * u_time;
    float scale = 5.0;
    float wavePositionA = 10.0 * (cos(trueWorldPos.x * scale) +
    sin(trueWorldPos.z * scale));
    float wavePositionB = 10.0 * (sin(trueWorldPos.x * scale) +
    cos(trueWorldPos.z * scale));

    waveStrength = 0.1 * (sin(waveTime + wavePositionA) *
    cos(waveTime + wavePositionB));

    vec4 modelPosition = u_modelMat * vec4(worldPos.x + xOff,
    worldPos.y + waveStrength - 0.2,
    worldPos.z + zOff, 1.0);
    gl_Position = u_projViewTrans * modelPosition;

    modelPosition = u_modelMat * vec4(cameraPosition, 1.0);
    worldPos = trueWorldPos;
}

```

### ./full/common/src/main/resources/assets/europa_client/shaders/chunk.frag.glsl:
```glsl
#version 150
#ifdef GL_ES
precision mediump float;
#endif

uniform vec3 cameraPosition;
uniform vec3 skyAmbientColor;
uniform vec4 tintColor;
uniform vec3 worldAmbientColor;

#import "base:shaders/common/renderDistance.glsl"

in vec2 v_texCoord0;
in vec3 worldPos;
in vec4 blocklight;
in vec3 faceNormal;

uniform sampler2D texDiffuse;
uniform vec3 u_sunDirection;

out vec4 outColor;
uniform float u_fogDensity;

#import "base:shaders/common/fog.glsl"

void main()
{
    vec2 tilingTexCoords = v_texCoord0;
    vec4 texColor = texture(texDiffuse, v_texCoord0);

    float fadeOutDistance = (u_renderDistanceInChunks - 1) * 16.0;
    float fadeOutFactor = clamp((fadeOutDistance - length(worldPos.xz -
    cameraPosition.xz)) / 16.0, 0.0, 1.0);
    texColor.a *= pow(fadeOutFactor, 0.5);

    if(texColor.a == 0.0)
    {
        discard;
    }

    vec3 lightTint = vec3(1.0);

    outColor = tintColor * vec4(texColor.rgb * lightTint, texColor.a);

    vec3 fogColor = skyAmbientColor;
    fogColor = getFogColor(fogColor, vec3(1.0), u_fogDensity, worldPos,
    cameraPosition);
    outColor.rgb = applyFog(fogColor, outColor.rgb, u_fogDensity, worldPos,
    cameraPosition);

    outColor.rgb = max(outColor.rgb, texColor.rgb);

    float gamma = 1.0;
    outColor.rgb = pow(outColor.rgb, vec3(1.0 / gamma));
}

```

### ./full/common/src/main/resources/assets/europa_client/shaders/chunk.vert.glsl:
```glsl
#version 150

in vec4 a_lighting;
uniform vec3 u_batchPosition;
uniform mat4 u_projViewTrans;
uniform mat4 u_modelMat;
uniform vec3 cameraPosition;

out vec2 v_texCoord0;
out vec3 worldPos;
out vec4 blocklight;
out vec3 faceNormal;

#import "base:shaders/common/bitUnpacker.glsl"

void main()
{
	worldPos = GET_BLOCK_VERT_POSITION + u_batchPosition;
	vec3 trueWorldPos = worldPos + cameraPosition;

	blocklight = vec4(1.0);

	v_texCoord0 = GET_TEX_COORDS;
	faceNormal = GET_FACE_NORMAL;

	vec4 modelPosition = u_modelMat * vec4(worldPos, 1.0);
	worldPos = modelPosition.xyz;
	gl_Position = u_projViewTrans * modelPosition;

	modelPosition = u_modelMat * vec4(trueWorldPos, 1.0);
	worldPos = modelPosition.xyz;
}

```

### ./full/common/src/main/resources/assets/europa_client/shaders/chunk-water.frag.glsl:
```glsl
#version 150
#ifdef GL_ES
precision mediump float;
#endif

uniform float u_time;
uniform vec3 cameraPosition;
uniform vec3 skyAmbientColor;
uniform vec3 skyColor;
uniform vec4 tintColor;
uniform vec3 worldAmbientColor;
uniform vec3 u_sunDirection;

#import "base:shaders/common/renderDistance.glsl"

in vec2 v_texCoord0;
in vec4 blocklight;
in float waveStrength;
in vec3 worldPos;
in vec3 toCameraVector;

uniform sampler2D texDiffuse;
uniform sampler2D noiseTex;

out vec4 outColor;

uniform float u_fogDensity;
#import "base:shaders/common/fog.glsl"

void main()
{
    vec2 numTiles = floor(v_texCoord0);
    vec2 tilingTexCoords = v_texCoord0;

    if(numTiles.xy != vec2(0.0, 0.0))
    {
        tilingTexCoords = (v_texCoord0 - numTiles);
        vec2 flooredTexCoords = floor((v_texCoord0 - numTiles) * 16.0) / 16.0;
        numTiles = numTiles + vec2(1.0, 1.0);
        tilingTexCoords = flooredTexCoords +
        mod(((tilingTexCoords - flooredTexCoords) * numTiles) * 16.0, 1.0)
        / 16.0;
    }

    vec4 texColor = texture(texDiffuse, tilingTexCoords);

    float fadeOutDistance = (u_renderDistanceInChunks - 1) * 16.0;
    float fadeOutFactor = clamp((fadeOutDistance - length(worldPos.xz -
    cameraPosition.xz)) / 16.0, 0.0, 1.0);
    float alpha = texColor.a * pow(fadeOutFactor, 0.5);
    if(alpha == 0.0)
    {
        discard;
    }

    vec3 waterColor = texColor.rgb;
    vec3 lightTint = vec3(1.0);

    outColor = tintColor * vec4(waterColor * lightTint, alpha);

    vec3 fogColor = vec3(1.0) - pow(vec3(1.0) - skyAmbientColor, vec3(2.0));
    fogColor = getFogColor(fogColor, vec3(1.0), u_fogDensity, worldPos,
    cameraPosition);
    outColor.rgb = applyFog(fogColor, outColor.rgb, u_fogDensity, worldPos,
    cameraPosition);

    outColor.rgb = max(outColor.rgb, texColor.rgb);

    float gamma = 1.0;
    outColor.rgb = pow(outColor.rgb, vec3(1.0 / gamma));
}

```

### ./full/quilt/build.gradle:
```gradle
plugins {
    id "application"
    id "maven-publish"
    id "cosmicloom"
}


loom {

}

repositories {
    ivy {
        name "Cosmic Reach"
        url "https://github.com/CRModders/CosmicArchive/raw/main/versions"
        patternLayout {
            artifact "[classifier]/[revision]/client/Cosmic-Reach-[revision].jar"
        }
        metadataSources {
            artifact()
        }
        content {
            includeModule "finalforeach", "cosmicreach"
        }
    }
    maven {
        name "JitPack"
        url "https://jitpack.io"
    }
    maven {
        name "Quilt"
        url "https://maven.quiltmc.org/repository/release"
    }
    maven {
        name "Fabric"
        url "https://maven.fabricmc.net/"
    }
    maven {
        name "Sponge"
        url "https://repo.spongepowered.org/maven/"
    }
    mavenCentral()
}

configurations {
    cosmicreach
    compileOnly.extendsFrom(cosmicreach)

    internal {
        visible = false
        canBeConsumed = false
        canBeResolved = false
    }
    compileClasspath.extendsFrom(internal)
    runtimeClasspath.extendsFrom(internal)
    testCompileClasspath.extendsFrom(internal)
    testRuntimeClasspath.extendsFrom(internal)
}

dependencies {
    // Cosmic Reach
    cosmicReach(loom.cosmicReachClient("alpha", cosmic_reach_version))
    cosmicReachServer(loom.cosmicReachServer("alpha", cosmic_reach_version))

    // Cosmic Quilt
    modImplementation(loom.cosmicQuilt(cosmic_quilt_version))

    // Depend on the common module for shared code.
    implementation project(":full:common")
}

tasks.withType(JavaCompile).configureEach {
    source(project(":full:common").sourceSets.main.allSource)
}

tasks.withType(Javadoc).configureEach {
    source(project(":full:common").sourceSets.main.allJava)
}

processResources {
    from project(":full:common").sourceSets.main.resources
    def resourceTargets = [ "quilt.mod.json" ]
    def replaceProperties = [
            mod_version      : project.version,
            mod_group        : project.group,
            mod_description  : project.description,
            mod_name         : project.name,
            mod_id           : rootProject.property("id")
    ]

    inputs.properties replaceProperties
    replaceProperties.put("project", project)
    filesMatching(resourceTargets) {
        expand replaceProperties
    }
}

application {
    mainClass = "org.quiltmc.loader.impl.launch.knot.KnotClient"
}

applicationDefaultJvmArgs = [
        "-Dloader.development=true",
        "-Dloader.gameJarPath=" + configurations.cosmicreach.asPath
]

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

jar {
    archiveFileName.set("${rootProject.name}-quilt-${project.version}.jar")
}
```

### ./full/quilt/src/main/java/dev/neuxs/europa_client/QuiltClient.java:
```java
package dev.neuxs.europa_client;

import dev.crmodders.cosmicquilt.api.entrypoint.ModInitializer;
import org.quiltmc.loader.api.ModContainer;

public class QuiltClient implements ModInitializer {
	@Override
	public void onInitialize(ModContainer mod) {
		Client.init();
	}
}

```

### ./full/quilt/src/main/resources/quilt.mod.json:
```json
{
  "schema_version": 1,

  "quilt_loader": {
    "group": "${mod_group}",
    "id": "${mod_id}",
    "version": "${mod_version}",

    "intermediate_mappings":"net.fabricmc:intermediary",

    "metadata": {
      "name": "Europa Client",
      "description": "${mod_description}",
      "contributors": {
        "Neuxs": "Owner"
      },

      "license": "MIT",

      "contact": {
        "homepage": "https://neuxs.dev/",
        "issues": "https://github.com/Neuxs0/Europa-Client/issues",
        "sources": "https://github.com/Neuxs0/Europa-Client"
      },

      "icon": "assets/${mod_id}/icon.png"
    },

    "entrypoints": {
      "init": "${mod_group}.${mod_id}.QuiltClient"
    },

    "depends": [
      {
        "id": "cosmicquilt",
        "versions": "*"
      },
      {
        "id": "cosmicreach",
        "versions": ">= 0.4.2"
      }
    ]
  },

  "mixin": [
    "${mod_id}.mixins.json"
  ]
}

```

### ./full/puzzle/build.gradle:
```gradle
plugins {
    id "java"
    id "jigsaw"
    id "com.github.johnrengelman.shadow"
}

loom {
    splitEnvironmentSourceSets()
    mods {
        "SimplyShaders" {
            sourceSet sourceSets.main
            sourceSet sourceSets.client
        }
    }
    accessWidenerPath = file("src/main/resources/${id}.manipulator")
}

repositories {
    mavenCentral()
    maven {
        url "https://jitpack.io"
    }
}

dependencies {
    // Referencing a Cosmic Reach dependency using the version from gradle.properties.
    cosmicReach("finalforeach:cosmicreach-alpha:${property("cosmic_reach_version")}")

    // Depend on the common module containing shared code.
    implementation project(":full:common")
}

tasks.named("compileClientJava") {
    source(project(":full:common").sourceSets.main.allSource)
}

tasks.named("compileClientJava") {
    source(project(":full:common").sourceSets.main.allJava)
}

processResources {
    def resourceTargets = ["puzzle.mod.json"]
    def replaceProperties = [
            mod_version     : project.version,
            mod_group       : project.group,
            mod_description : project.description,
            mod_name        : project.name,
            mod_id          : rootProject.property("id")
    ]

    inputs.properties replaceProperties
    replaceProperties.put("project", project)
    filesMatching(resourceTargets) {
        expand replaceProperties
    }
}

jar {
    archiveFileName.set("${rootProject.name}-puzzle-${project.version}.jar")
}

// New task to copy europa_client.mixins.json from the common module.
tasks.register("copyMixins", Copy) {
    from(file("../full/common/src/main/resources/europa_client.mixins.json"))
    into(file("src/client/resources"))
    // Declaring the output directory helps Gradle with up-to-date checks.
    outputs.dir file("src/client/resources")
}

// Make sure processClientResources waits for the copyMixins task.
tasks.named("processClientResources") {
    dependsOn tasks.named("copyMixins")
}

// Optionally, if the jar task also relies on the copied file, ensure it depends on copyMixins.
jar.dependsOn(tasks.named("copyMixins"))

```

### ./full/puzzle/src/main/resources/europa_client.manipulator:
```manipulator

```

### ./full/puzzle/src/main/resources/puzzle.mod.json:
```json
{
  "formatVersion": 1,
  "group": "${mod_group}",
  "id": "${mod_id}",
  "version": "${mod_version}",
  "name": "Europa Client",
  "description": "${mod_description}",
  "authors": [
    "Neuxs"
  ],
  "license": "MIT",
  "meta": {
    "icon": "${mod_id}:icons/icon.png"
  },
  "entrypoints": {
    "client_init": [
      "${mod_group}.${mod_id}.PuzzleClient"
    ]
  },
  "mixins": [
    "${mod_id}.mixins.json"
  ],
  "depends": {
    "cosmic-reach": ">=0.4.2",
    "puzzle-loader": ">=2.3.7"
  },
  "accessTransformers": [
    "${mod_id}.manipulator"
  ]
}
```

### ./full/puzzle/src/client/java/dev/neuxs/europa_client/PuzzleClient.java:
```java
package dev.neuxs.europa_client;

import com.github.puzzle.core.loader.launch.provider.mod.entrypoint.impls.ClientModInitializer;

public class PuzzleClient implements ClientModInitializer {
    @Override
    public void onInit() {
        Client.init();
    }
}
```

### ./full/puzzle/src/client/resources/europa_client.mixins.json:
```json
{
  "required": true,
  "minVersion": "0.8",
  "package": "dev.neuxs.europa_client.mixins",
  "compatibilityLevel": "JAVA_17",
  "mixins": [
    "UIMixin",
    "EntityMixin",
    "ChatMenuMixin",
    "YouDiedMenuMixin",
    "NoClipPacketMixin",
    "GameSingletonsInterface"
  ],
  "client": [
  ],
  "injectors": {
    "defaultRequire": 1
  }
}
```
